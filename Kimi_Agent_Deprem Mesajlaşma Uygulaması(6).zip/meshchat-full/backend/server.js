/**
 * MeshChat Backend Server
 * Express + SQLite + WebSocket
 */

const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const sqlite3 = require('sqlite3').verbose();
const WebSocket = require('ws');
const http = require('http');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
require('dotenv').config();

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.static(path.join(__dirname, '../frontend/dist')));

// Uploads klasörü
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}
app.use('/uploads', express.static(uploadsDir));

// Veritabanı bağlantısı
const dbPath = process.env.DB_PATH || path.join(__dirname, 'meshchat.db');
const db = new sqlite3.Database(dbPath);

// JWT Secret
const JWT_SECRET = process.env.JWT_SECRET || 'meshchat-super-secret-key-2024';

// ==================== VERITABANI TABLOLARI ====================

function initDatabase() {
  return new Promise((resolve, reject) => {
    db.serialize(() => {
      // Kullanıcılar tablosu
      db.run(`CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        email TEXT UNIQUE NOT NULL,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        displayName TEXT NOT NULL,
        avatar TEXT,
        publicKey TEXT,
        status TEXT DEFAULT 'offline',
        createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
        lastSeen DATETIME DEFAULT CURRENT_TIMESTAMP
      )`);

      // Mesajlar tablosu
      db.run(`CREATE TABLE IF NOT EXISTS messages (
        id TEXT PRIMARY KEY,
        senderId TEXT NOT NULL,
        receiverId TEXT NOT NULL,
        content TEXT NOT NULL,
        encryptedContent TEXT,
        type TEXT DEFAULT 'text',
        mediaUrl TEXT,
        status TEXT DEFAULT 'sent',
        signature TEXT,
        createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (senderId) REFERENCES users(id),
        FOREIGN KEY (receiverId) REFERENCES users(id)
      )`);

      // Sohbetler tablosu
      db.run(`CREATE TABLE IF NOT EXISTS chats (
        id TEXT PRIMARY KEY,
        participant1Id TEXT NOT NULL,
        participant2Id TEXT NOT NULL,
        lastMessageId TEXT,
        unreadCount1 INTEGER DEFAULT 0,
        unreadCount2 INTEGER DEFAULT 0,
        updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (participant1Id) REFERENCES users(id),
        FOREIGN KEY (participant2Id) REFERENCES users(id)
      )`);

      // Botlar tablosu
      db.run(`CREATE TABLE IF NOT EXISTS bots (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        username TEXT UNIQUE NOT NULL,
        description TEXT,
        ownerId TEXT NOT NULL,
        token TEXT UNIQUE NOT NULL,
        script TEXT,
        language TEXT DEFAULT 'python',
        isActive INTEGER DEFAULT 0,
        webhookUrl TEXT,
        createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (ownerId) REFERENCES users(id)
      )`);

      // Duvar gönderileri tablosu
      db.run(`CREATE TABLE IF NOT EXISTS wall_posts (
        id TEXT PRIMARY KEY,
        userId TEXT NOT NULL,
        content TEXT NOT NULL,
        mediaUrls TEXT,
        mediaType TEXT DEFAULT 'none',
        taggedUsers TEXT,
        likes INTEGER DEFAULT 0,
        createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (userId) REFERENCES users(id)
      )`);

      // Yorumlar tablosu
      db.run(`CREATE TABLE IF NOT EXISTS comments (
        id TEXT PRIMARY KEY,
        postId TEXT NOT NULL,
        userId TEXT NOT NULL,
        content TEXT NOT NULL,
        createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (postId) REFERENCES wall_posts(id),
        FOREIGN KEY (userId) REFERENCES users(id)
      )`);

      // Admin kullanıcısı oluştur
      const adminId = uuidv4();
      const adminPassword = bcrypt.hashSync('admin123', 10);
      
      db.run(`INSERT OR IGNORE INTO users (id, email, username, password, displayName, publicKey) 
        VALUES (?, 'admin@meshchat.com', 'admin', ?, 'Sistem Yöneticisi', '')`,
        [adminId, adminPassword],
        (err) => {
          if (err) console.log('Admin zaten var veya hata:', err);
        }
      );

      console.log('✅ Veritabanı hazır!');
      resolve();
    });
  });
}

// ==================== JWT MIDDLEWARE ====================

function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ success: false, error: 'Token gerekli' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ success: false, error: 'Geçersiz token' });
    }
    req.user = user;
    next();
  });
}

// ==================== AUTH ROUTES ====================

// Kayıt
app.post('/api/auth/register', async (req, res) => {
  try {
    const { email, password, username, displayName, publicKey } = req.body;

    // Validasyon
    if (!email || !password || !username || !displayName) {
      return res.status(400).json({ success: false, error: 'Tüm alanlar gerekli' });
    }

    // Şifre hashleme
    const hashedPassword = await bcrypt.hash(password, 10);
    const userId = uuidv4();

    db.run(
      `INSERT INTO users (id, email, username, password, displayName, publicKey) VALUES (?, ?, ?, ?, ?, ?)`,
      [userId, email, username, hashedPassword, displayName, publicKey || ''],
      function(err) {
        if (err) {
          if (err.message.includes('UNIQUE constraint failed')) {
            return res.status(400).json({ success: false, error: 'Email veya kullanıcı adı zaten kullanımda' });
          }
          return res.status(500).json({ success: false, error: 'Kayıt başarısız' });
        }

        const token = jwt.sign({ userId, email, username }, JWT_SECRET, { expiresIn: '7d' });
        const refreshToken = jwt.sign({ userId }, JWT_SECRET, { expiresIn: '30d' });

        res.json({
          success: true,
          token,
          refreshToken,
          user: { id: userId, email, username, displayName }
        });
      }
    );
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Giriş
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;

  db.get(`SELECT * FROM users WHERE email = ? OR username = ?`, [email, email], async (err, user) => {
    if (err || !user) {
      return res.status(401).json({ success: false, error: 'Kullanıcı bulunamadı' });
    }

    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) {
      return res.status(401).json({ success: false, error: 'Şifre hatalı' });
    }

    // Son görülme güncelle
    db.run(`UPDATE users SET status = 'online', lastSeen = CURRENT_TIMESTAMP WHERE id = ?`, [user.id]);

    const token = jwt.sign(
      { userId: user.id, email: user.email, username: user.username },
      JWT_SECRET,
      { expiresIn: '7d' }
    );
    const refreshToken = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: '30d' });

    res.json({
      success: true,
      token,
      refreshToken,
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        displayName: user.displayName,
        avatar: user.avatar,
        status: 'online'
      }
    });
  });
});

// Token doğrulama
app.get('/api/auth/validate', authenticateToken, (req, res) => {
  db.get(`SELECT id, email, username, displayName, avatar, status FROM users WHERE id = ?`, 
    [req.user.userId], 
    (err, user) => {
      if (err || !user) {
        return res.status(404).json({ success: false, error: 'Kullanıcı bulunamadı' });
      }
      res.json({ success: true, user });
    }
  );
});

// ==================== MESAJ ROUTES ====================

// Mesaj gönder
app.post('/api/messages', authenticateToken, (req, res) => {
  const { receiverId, content, encryptedContent, type, mediaUrl, signature } = req.body;
  const senderId = req.user.userId;
  const messageId = uuidv4();

  db.run(
    `INSERT INTO messages (id, senderId, receiverId, content, encryptedContent, type, mediaUrl, signature) 
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [messageId, senderId, receiverId, content, encryptedContent, type || 'text', mediaUrl, signature],
    function(err) {
      if (err) {
        return res.status(500).json({ success: false, error: 'Mesaj gönderilemedi' });
      }

      // Sohbeti güncelle veya oluştur
      const chatId = [senderId, receiverId].sort().join('_');
      db.run(
        `INSERT INTO chats (id, participant1Id, participant2Id, lastMessageId, updatedAt) 
         VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
         ON CONFLICT(id) DO UPDATE SET lastMessageId = excluded.lastMessageId, updatedAt = CURRENT_TIMESTAMP`,
        [chatId, senderId, receiverId, messageId]
      );

      // WebSocket ile bildir
      broadcastToUser(receiverId, {
        type: 'message',
        message: { id: messageId, senderId, receiverId, content, type, createdAt: new Date() }
      });

      res.json({ success: true, message: { id: messageId, senderId, receiverId, content, type } });
    }
  );
});

// Mesajları getir
app.get('/api/messages/:chatId', authenticateToken, (req, res) => {
  const { chatId } = req.params;
  const { limit = 50, offset = 0 } = req.query;
  const userId = req.user.userId;

  const [user1, user2] = chatId.split('_');
  if (user1 !== userId && user2 !== userId) {
    return res.status(403).json({ success: false, error: 'Yetkisiz erişim' });
  }

  db.all(
    `SELECT * FROM messages 
     WHERE (senderId = ? AND receiverId = ?) OR (senderId = ? AND receiverId = ?)
     ORDER BY createdAt DESC LIMIT ? OFFSET ?`,
    [user1, user2, user2, user1, parseInt(limit), parseInt(offset)],
    (err, messages) => {
      if (err) {
        return res.status(500).json({ success: false, error: 'Mesajlar alınamadı' });
      }
      res.json({ success: true, messages: messages.reverse() });
    }
  );
});

// Sohbetleri getir
app.get('/api/chats', authenticateToken, (req, res) => {
  const userId = req.user.userId;

  db.all(
    `SELECT c.*, 
      u1.id as u1_id, u1.username as u1_username, u1.displayName as u1_displayName, u1.avatar as u1_avatar,
      u2.id as u2_id, u2.username as u2_username, u2.displayName as u2_displayName, u2.avatar as u2_avatar,
      m.content as lastMessageContent, m.createdAt as lastMessageTime
     FROM chats c
     JOIN users u1 ON c.participant1Id = u1.id
     JOIN users u2 ON c.participant2Id = u2.id
     LEFT JOIN messages m ON c.lastMessageId = m.id
     WHERE c.participant1Id = ? OR c.participant2Id = ?
     ORDER BY c.updatedAt DESC`,
    [userId, userId],
    (err, rows) => {
      if (err) {
        return res.status(500).json({ success: false, error: 'Sohbetler alınamadı' });
      }

      const chats = rows.map(row => {
        const isParticipant1 = row.participant1Id === userId;
        const otherUser = isParticipant1 ? 
          { id: row.u2_id, username: row.u2_username, displayName: row.u2_displayName, avatar: row.u2_avatar } :
          { id: row.u1_id, username: row.u1_username, displayName: row.u1_displayName, avatar: row.u1_avatar };

        return {
          id: row.id,
          participants: [otherUser],
          lastMessage: row.lastMessageContent ? { content: row.lastMessageContent, timestamp: row.lastMessageTime } : null,
          unreadCount: isParticipant1 ? row.unreadCount1 : row.unreadCount2,
          updatedAt: row.updatedAt
        };
      });

      res.json({ success: true, chats });
    }
  );
});

// ==================== BOT ROUTES ====================

// Bot oluştur
app.post('/api/bots', authenticateToken, (req, res) => {
  const { name, username, description, language } = req.body;
  const ownerId = req.user.userId;
  const botId = uuidv4();
  const token = 'bot_' + uuidv4().replace(/-/g, '');

  const defaultScript = language === 'python' 
    ? `# MeshChat Bot\nclass Bot:\n    def handle(self, msg):\n        return f"Echo: {msg}"`
    : `// MeshChat Bot\nfunction handle(msg) {\n    return "Echo: " + msg;\n}`;

  db.run(
    `INSERT INTO bots (id, name, username, description, ownerId, token, script, language) 
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [botId, name, username, description, ownerId, token, defaultScript, language || 'python'],
    function(err) {
      if (err) {
        return res.status(400).json({ success: false, error: 'Bot kullanıcı adı zaten kullanımda' });
      }
      res.json({ success: true, bot: { id: botId, name, username, description, token, language } });
    }
  );
});

// Botları getir
app.get('/api/bots', authenticateToken, (req, res) => {
  db.all(
    `SELECT id, name, username, description, language, isActive, createdAt FROM bots WHERE ownerId = ?`,
    [req.user.userId],
    (err, bots) => {
      if (err) {
        return res.status(500).json({ success: false, error: 'Botlar alınamadı' });
      }
      res.json({ success: true, bots });
    }
  );
});

// Bot mesaj gönder (Bot token ile)
app.post('/api/bots/send', (req, res) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token || !token.startsWith('bot_')) {
    return res.status(401).json({ success: false, error: 'Bot token gerekli' });
  }

  db.get(`SELECT * FROM bots WHERE token = ?`, [token], (err, bot) => {
    if (err || !bot) {
      return res.status(401).json({ success: false, error: 'Geçersiz bot token' });
    }

    const { chat_id, text } = req.body;
    const messageId = uuidv4();

    db.run(
      `INSERT INTO messages (id, senderId, receiverId, content, type) VALUES (?, ?, ?, ?, 'text')`,
      [messageId, bot.id, chat_id, text],
      function(err) {
        if (err) {
          return res.status(500).json({ success: false, error: 'Mesaj gönderilemedi' });
        }

        broadcastToUser(chat_id, {
          type: 'message',
          message: { id: messageId, senderId: bot.id, receiverId: chat_id, content: text, type: 'text' }
        });

        res.json({ success: true, message_id: messageId });
      }
    );
  });
});

// ==================== WALL ROUTES ====================

// Gönderi oluştur
app.post('/api/wall/posts', authenticateToken, (req, res) => {
  const { content, mediaUrls, mediaType, taggedUsers } = req.body;
  const userId = req.user.userId;
  const postId = uuidv4();

  db.run(
    `INSERT INTO wall_posts (id, userId, content, mediaUrls, mediaType, taggedUsers) VALUES (?, ?, ?, ?, ?, ?)`,
    [postId, userId, content, JSON.stringify(mediaUrls || []), mediaType || 'none', JSON.stringify(taggedUsers || [])],
    function(err) {
      if (err) {
        return res.status(500).json({ success: false, error: 'Gönderi oluşturulamadı' });
      }
      res.json({ success: true, post: { id: postId, userId, content, mediaUrls, createdAt: new Date() } });
    }
  );
});

// Kullanıcı duvarını getir
app.get('/api/wall/users/:userId/posts', authenticateToken, (req, res) => {
  const { userId } = req.params;
  const { limit = 20, offset = 0 } = req.query;

  db.all(
    `SELECT wp.*, u.username, u.displayName, u.avatar 
     FROM wall_posts wp
     JOIN users u ON wp.userId = u.id
     WHERE wp.userId = ?
     ORDER BY wp.createdAt DESC LIMIT ? OFFSET ?`,
    [userId, parseInt(limit), parseInt(offset)],
    (err, posts) => {
      if (err) {
        return res.status(500).json({ success: false, error: 'Gönderiler alınamadı' });
      }
      res.json({ success: true, posts });
    }
  );
});

// ==================== ADMIN ROUTES ====================

// Admin - Tüm kullanıcılar
app.get('/api/admin/users', authenticateToken, (req, res) => {
  if (req.user.username !== 'admin') {
    return res.status(403).json({ success: false, error: 'Yetkisiz erişim' });
  }

  db.all(`SELECT id, email, username, displayName, status, createdAt, lastSeen FROM users`, [], (err, users) => {
    if (err) {
      return res.status(500).json({ success: false, error: 'Kullanıcılar alınamadı' });
    }
    res.json({ success: true, users });
  });
});

// Admin - İstatistikler
app.get('/api/admin/stats', authenticateToken, (req, res) => {
  if (req.user.username !== 'admin') {
    return res.status(403).json({ success: false, error: 'Yetkisiz erişim' });
  }

  db.get(`SELECT COUNT(*) as userCount FROM users`, [], (err, userRow) => {
    db.get(`SELECT COUNT(*) as messageCount FROM messages`, [], (err, msgRow) => {
      db.get(`SELECT COUNT(*) as botCount FROM bots`, [], (err, botRow) => {
        res.json({
          success: true,
          stats: {
            users: userRow.userCount,
            messages: msgRow.messageCount,
            bots: botRow.botCount
          }
        });
      });
    });
  });
});

// ==================== WEBSOCKET ====================

const clients = new Map();

wss.on('connection', (ws, req) => {
  const url = new URL(req.url, 'http://localhost');
  const token = url.searchParams.get('token');

  if (!token) {
    ws.close(1008, 'Token gerekli');
    return;
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      ws.close(1008, 'Geçersiz token');
      return;
    }

    clients.set(user.userId, ws);
    console.log(`✅ WebSocket bağlantısı: ${user.username}`);

    ws.on('message', (data) => {
      try {
        const message = JSON.parse(data);
        handleWebSocketMessage(user.userId, message);
      } catch (e) {
        console.error('WebSocket mesaj hatası:', e);
      }
    });

    ws.on('close', () => {
      clients.delete(user.userId);
      db.run(`UPDATE users SET status = 'offline', lastSeen = CURRENT_TIMESTAMP WHERE id = ?`, [user.userId]);
      console.log(`❌ WebSocket bağlantısı kapandı: ${user.username}`);
    });

    ws.send(JSON.stringify({ type: 'connected', userId: user.userId }));
  });
});

function handleWebSocketMessage(userId, message) {
  switch (message.type) {
    case 'typing':
      // Yazıyor bildirimi
      broadcastToUser(message.receiverId, {
        type: 'typing',
        senderId: userId
      });
      break;
    case 'read_receipt':
      // Okundu bildirimi
      broadcastToUser(message.receiverId, {
        type: 'read_receipt',
        chatId: message.chatId
      });
      break;
  }
}

function broadcastToUser(userId, data) {
  const client = clients.get(userId);
  if (client && client.readyState === WebSocket.OPEN) {
    client.send(JSON.stringify(data));
  }
}

// ==================== ANA SAYFA ====================

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/dist/index.html'));
});

// ==================== SUNUCU BAŞLATMA ====================

const PORT = process.env.PORT || 3000;

initDatabase().then(() => {
  server.listen(PORT, () => {
    console.log(`
╔════════════════════════════════════════════════════════════╗
║                                                            ║
║   🚀 MeshChat Server Çalışıyor!                            ║
║                                                            ║
║   📱 Web: http://localhost:${PORT}                          ║
║   🔌 API: http://localhost:${PORT}/api                      ║
║   💾 DB: ${dbPath}                    ║
║                                                            ║
║   👤 Admin: admin@meshchat.com / admin123                  ║
║                                                            ║
╚════════════════════════════════════════════════════════════╝
    `);
  });
});

module.exports = { app, server };
