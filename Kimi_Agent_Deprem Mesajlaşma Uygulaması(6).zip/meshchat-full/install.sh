#!/bin/bash
# MeshChat Kurulum Scripti (Linux/Mac)

echo "=================================="
echo "  MeshChat Kurulumu"
echo "=================================="
echo ""

# Node.js kontrol
if ! command -v node &> /dev/null; then
    echo "❌ Node.js bulunamadi!"
    echo "Lutfen once Node.js yukleyin: https://nodejs.org"
    exit 1
fi

echo "✅ Node.js bulundu: $(node --version)"
echo ""

# Backend kurulum
echo "🔧 Backend kuruluyor..."
cd backend
npm install
cd ..

# JWT Secret olustur
if [ ! -f backend/.env ]; then
    echo "JWT_SECRET=meshchat-$(date +%s)" > backend/.env
fi

echo ""
echo "=================================="
echo "  ✅ Kurulum Tamamlandi!"
echo "=================================="
echo ""
echo "Baslatmak icin:"
echo "  cd backend && npm start"
echo ""
echo "Site: http://localhost:3000"
echo "Admin: admin@meshchat.com / admin123"
echo ""
