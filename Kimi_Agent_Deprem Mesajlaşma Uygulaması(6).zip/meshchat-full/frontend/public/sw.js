// MeshChat Service Worker - Çevrimdışı Çalışma
const CACHE_NAME = 'meshchat-v1';
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icon-192x192.png',
  '/icon-512x512.png'
];

// Kurulum
self.addEventListener('install', (event) => {
  console.log('[SW] Kuruluyor...');
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(STATIC_ASSETS))
      .then(() => self.skipWaiting())
  );
});

// Aktivasyon
self.addEventListener('activate', (event) => {
  console.log('[SW] Aktive ediliyor...');
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames
          .filter(name => name !== CACHE_NAME)
          .map(name => caches.delete(name))
      );
    }).then(() => self.clients.claim())
  );
});

// Fetch - Çevrimdışı desteği
self.addEventListener('fetch', (event) => {
  const { request } = event;
  
  // API istekleri
  if (request.url.includes('/api/')) {
    event.respondWith(
      fetch(request)
        .then(response => {
          // Başarılı yanıtı cache'e al
          const clone = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(request, clone));
          return response;
        })
        .catch(() => {
          // Çevrimdışı - cache'den dene
          return caches.match(request).then(cached => {
            if (cached) return cached;
            // Mesajları IndexedDB'den dene
            return getOfflineMessages(request);
          });
        })
    );
    return;
  }
  
  // Statik dosyalar
  event.respondWith(
    caches.match(request).then(cached => {
      if (cached) return cached;
      return fetch(request).then(response => {
        const clone = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(request, clone));
        return response;
      });
    })
  );
});

// IndexedDB'den mesajları al
async function getOfflineMessages(request) {
  // Basit bir offline yanıt
  return new Response(
    JSON.stringify({ 
      success: false, 
      offline: true,
      error: 'Çevrimdışı moddasınız. Mesajınız gönderilecek bağlantı sağlandığında.' 
    }),
    { headers: { 'Content-Type': 'application/json' } }
  );
}

// Arka plan senkronizasyonu
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-messages') {
    event.waitUntil(syncPendingMessages());
  }
});

async function syncPendingMessages() {
  // IndexedDB'den bekleyen mesajları al ve gönder
  console.log('[SW] Mesajlar senkronize ediliyor...');
}

// Push bildirimleri
self.addEventListener('push', (event) => {
  const data = event.data.json();
  event.waitUntil(
    self.registration.showNotification(data.title, {
      body: data.body,
      icon: '/icon-192x192.png',
      badge: '/icon-72x72.png',
      tag: data.tag
    })
  );
});

console.log('[SW] Service Worker yüklendi');
