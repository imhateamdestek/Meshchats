import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { Users, MessageSquare, Bot, ArrowLeft, User } from 'lucide-react'
import './Admin.css'

interface Stats {
  users: number
  messages: number
  bots: number
}

interface UserData {
  id: string
  email: string
  username: string
  displayName: string
  status: string
  createdAt: string
  lastSeen: string
}

function Admin() {
  const navigate = useNavigate()
  const { user, token } = useAuth()
  const [stats, setStats] = useState<Stats>({ users: 0, messages: 0, bots: 0 })
  const [users, setUsers] = useState<UserData[]>([])
  const [activeTab, setActiveTab] = useState<'dashboard' | 'users'>('dashboard')

  useEffect(() => {
    // İstatistikleri yükle
    fetch('/api/admin/stats', {
      headers: { 'Authorization': `Bearer ${token}` }
    })
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        setStats(data.stats)
      }
    })

    // Kullanıcıları yükle
    fetch('/api/admin/users', {
      headers: { 'Authorization': `Bearer ${token}` }
    })
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        setUsers(data.users)
      }
    })
  }, [token])

  if (user?.username !== 'admin') {
    return <div>Yetkisiz erişim</div>
  }

  return (
    <div className="admin-page">
      {/* Sidebar */}
      <aside className="admin-sidebar">
        <div className="admin-header">
          <button className="back-btn" onClick={() => navigate('/chat')}>
            <ArrowLeft size={20} />
          </button>
          <h2>Admin Panel</h2>
        </div>
        
        <nav className="admin-nav">
          <button 
            className={activeTab === 'dashboard' ? 'active' : ''}
            onClick={() => setActiveTab('dashboard')}
          >
            Dashboard
          </button>
          <button 
            className={activeTab === 'users' ? 'active' : ''}
            onClick={() => setActiveTab('users')}
          >
            Kullanıcılar
          </button>
        </nav>
      </aside>

      {/* Main Content */}
      <main className="admin-main">
        {activeTab === 'dashboard' ? (
          <>
            <h1>Dashboard</h1>
            
            <div className="stats-grid">
              <div className="stat-card">
                <div className="stat-icon users">
                  <Users size={32} />
                </div>
                <div className="stat-info">
                  <h3>{stats.users}</h3>
                  <p>Kullanıcı</p>
                </div>
              </div>
              
              <div className="stat-card">
                <div className="stat-icon messages">
                  <MessageSquare size={32} />
                </div>
                <div className="stat-info">
                  <h3>{stats.messages}</h3>
                  <p>Mesaj</p>
                </div>
              </div>
              
              <div className="stat-card">
                <div className="stat-icon bots">
                  <Bot size={32} />
                </div>
                <div className="stat-info">
                  <h3>{stats.bots}</h3>
                  <p>Bot</p>
                </div>
              </div>
            </div>

            <div className="info-card">
              <h3>Sistem Bilgileri</h3>
              <div className="info-row">
                <span>Versiyon:</span>
                <span>1.0.0</span>
              </div>
              <div className="info-row">
                <span>Veritabanı:</span>
                <span>SQLite</span>
              </div>
              <div className="info-row">
                <span>WebSocket:</span>
                <span className="status online">Aktif</span>
              </div>
            </div>
          </>
        ) : (
          <>
            <h1>Kullanıcılar</h1>
            
            <div className="users-table">
              <table>
                <thead>
                  <tr>
                    <th>Kullanıcı</th>
                    <th>E-posta</th>
                    <th>Durum</th>
                    <th>Kayıt Tarihi</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map(u => (
                    <tr key={u.id}>
                      <td>
                        <div className="user-cell">
                          <div className="user-avatar">
                            <User size={20} />
                          </div>
                          <div>
                            <p className="user-name">{u.displayName}</p>
                            <p className="user-username">@{u.username}</p>
                          </div>
                        </div>
                      </td>
                      <td>{u.email}</td>
                      <td>
                        <span className={`status-badge ${u.status}`}>
                          {u.status === 'online' ? 'Çevrimiçi' : 'Çevrimdışı'}
                        </span>
                      </td>
                      <td>{new Date(u.createdAt).toLocaleDateString('tr-TR')}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </main>
    </div>
  )
}

export default Admin
