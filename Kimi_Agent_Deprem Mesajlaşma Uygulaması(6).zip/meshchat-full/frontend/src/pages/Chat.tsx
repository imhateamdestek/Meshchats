import { useState, useEffect, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { 
  Send, 
  LogOut, 
  User, 
  Settings, 
  Bot,
  Wifi,
  Bluetooth,
  Radio,
  Menu,
  X
} from 'lucide-react'
import './Chat.css'

interface Message {
  id: string
  senderId: string
  receiverId: string
  content: string
  type: string
  createdAt: string
}

interface Chat {
  id: string
  participants: any[]
  lastMessage?: { content: string; timestamp: string }
  unreadCount: number
}

function Chat() {
  const navigate = useNavigate()
  const { user, logout, token } = useAuth()
  const [chats, setChats] = useState<Chat[]>([])
  const [activeChat, setActiveChat] = useState<Chat | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState('')
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [networkStatus, setNetworkStatus] = useState('online')
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const wsRef = useRef<WebSocket | null>(null)

  // WebSocket bağlantısı
  useEffect(() => {
    if (!token) return

    const wsUrl = `wss://${window.location.host}/ws?token=${token}`
    const ws = new WebSocket(wsUrl.replace('wss://', 'ws://'))
    
    ws.onopen = () => {
      console.log('WebSocket bağlandı')
      setNetworkStatus('online')
    }
    
    ws.onmessage = (event) => {
      const data = JSON.parse(event.data)
      if (data.type === 'message') {
        setMessages(prev => [...prev, data.message])
      }
    }
    
    ws.onclose = () => {
      console.log('WebSocket kapandı')
      setNetworkStatus('offline')
    }
    
    wsRef.current = ws
    
    return () => ws.close()
  }, [token])

  // Sohbetleri yükle
  useEffect(() => {
    fetch('/api/chats', {
      headers: { 'Authorization': `Bearer ${token}` }
    })
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        setChats(data.chats)
      }
    })
  }, [token])

  // Mesajları yükle
  useEffect(() => {
    if (!activeChat) return
    
    fetch(`/api/messages/${activeChat.id}`, {
      headers: { 'Authorization': `Bearer ${token}` }
    })
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        setMessages(data.messages)
      }
    })
  }, [activeChat, token])

  // Otomatik scroll
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const sendMessage = async () => {
    if (!newMessage.trim() || !activeChat) return

    const receiver = activeChat.participants[0]
    
    try {
      const response = await fetch('/api/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          receiverId: receiver.id,
          content: newMessage,
          type: 'text'
        })
      })

      const data = await response.json()
      
      if (data.success) {
        setMessages(prev => [...prev, data.message])
        setNewMessage('')
      }
    } catch (err) {
      console.error('Mesaj gönderme hatası:', err)
    }
  }

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  const getNetworkIcon = () => {
    switch(networkStatus) {
      case 'online': return <Wifi size={18} />
      case 'mesh': return <Radio size={18} />
      case 'bluetooth': return <Bluetooth size={18} />
      default: return <Radio size={18} />
    }
  }

  return (
    <div className="chat-page">
      {/* Sidebar */}
      <aside className={`sidebar ${sidebarOpen ? 'open' : ''}`}>
        <div className="sidebar-header">
          <h2>MeshChat</h2>
          <button className="close-sidebar" onClick={() => setSidebarOpen(false)}>
            <X size={24} />
          </button>
        </div>

        <div className="user-info">
          <div className="avatar">
            <User size={24} />
          </div>
          <div>
            <p className="user-name">{user?.displayName}</p>
            <p className="user-status">
              {getNetworkIcon()}
              <span>{networkStatus === 'online' ? 'Çevrimiçi' : 'Çevrimdışı'}</span>
            </p>
          </div>
        </div>

        <nav className="sidebar-nav">
          <button onClick={() => navigate('/chat')}>
            <MessageCircleIcon /> Sohbetler
          </button>
          <button onClick={() => navigate('/bots')}>
            <Bot size={20} /> Botlarım
          </button>
          <button onClick={() => navigate('/settings')}>
            <Settings size={20} /> Ayarlar
          </button>
          {user?.username === 'admin' && (
            <button onClick={() => navigate('/admin')}>
              <Settings size={20} /> Admin Panel
            </button>
          )}
        </nav>

        <button className="logout-btn" onClick={handleLogout}>
          <LogOut size={20} /> Çıkış Yap
        </button>
      </aside>

      {/* Ana İçerik */}
      <main className="chat-main">
        {/* Header */}
        <header className="chat-header">
          <button className="menu-btn" onClick={() => setSidebarOpen(true)}>
            <Menu size={24} />
          </button>
          
          {activeChat ? (
            <div className="chat-info">
              <h3>{activeChat.participants[0]?.displayName}</h3>
              <span className="status">{activeChat.participants[0]?.status || 'Çevrimdışı'}</span>
            </div>
          ) : (
            <h3>Sohbetler</h3>
          )}
        </header>

        {/* Chat List veya Mesajlar */}
        {!activeChat ? (
          <div className="chat-list">
            {chats.length === 0 ? (
              <div className="empty-state">
                <p>Henüz sohbet yok</p>
                <p className="hint">Yeni bir sohbet başlatmak için kullanıcı arayın</p>
              </div>
            ) : (
              chats.map(chat => (
                <div 
                  key={chat.id} 
                  className="chat-item"
                  onClick={() => setActiveChat(chat)}
                >
                  <div className="chat-avatar">
                    <User size={32} />
                  </div>
                  <div className="chat-details">
                    <h4>{chat.participants[0]?.displayName}</h4>
                    <p className="last-message">
                      {chat.lastMessage?.content || 'Henüz mesaj yok'}
                    </p>
                  </div>
                  {chat.unreadCount > 0 && (
                    <span className="unread-badge">{chat.unreadCount}</span>
                  )}
                </div>
              ))
            )}
          </div>
        ) : (
          <>
            <div className="messages">
              {messages.map(msg => (
                <div 
                  key={msg.id} 
                  className={`message ${msg.senderId === user?.id ? 'sent' : 'received'}`}
                >
                  <div className="message-content">
                    {msg.content}
                  </div>
                  <span className="message-time">
                    {new Date(msg.createdAt).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            <div className="message-input">
              <button className="back-btn" onClick={() => setActiveChat(null)}>
                ←
              </button>
              <input
                type="text"
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                placeholder="Mesaj yazın..."
              />
              <button className="send-btn" onClick={sendMessage}>
                <Send size={20} />
              </button>
            </div>
          </>
        )}
      </main>
    </div>
  )
}

// MessageCircle icon (lucide-react'ta olmayan)
function MessageCircleIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
    </svg>
  )
}

export default Chat
