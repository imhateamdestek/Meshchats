import { useNavigate } from 'react-router-dom'
import { MessageCircle, Wifi, Shield, Smartphone, Radio, Code } from 'lucide-react'
import './Landing.css'

function Landing() {
  const navigate = useNavigate()

  return (
    <div className="landing">
      {/* Hero */}
      <section className="hero">
        <div className="hero-content">
          <div className="logo">
            <MessageCircle size={64} />
          </div>
          <h1>MeshChat</h1>
          <p className="tagline">
            Deprem anında bile çalışan, telefondan telefona iletişim kuran 
            <span className="highlight"> süper güvenli</span> mesajlaşma!
          </p>
          <p className="subtagline">
            İnternet yoksa WiFi, WiFi yoksa Bluetooth, hiçbiri yoksa Mesh Ağı!
          </p>
          <div className="buttons">
            <button className="btn-primary" onClick={() => navigate('/register')}>
              Hemen Başla
            </button>
            <button className="btn-secondary" onClick={() => navigate('/login')}>
              Giriş Yap
            </button>
          </div>
        </div>
      </section>

      {/* Özellikler */}
      <section className="features">
        <h2>Neden MeshChat?</h2>
        <div className="feature-grid">
          <div className="feature-card">
            <Radio size={40} className="feature-icon" />
            <h3>Mesh Ağı</h3>
            <p>İnternet olmadan telefondan telefona iletişim</p>
          </div>
          <div className="feature-card">
            <Shield size={40} className="feature-icon" />
            <h3>Uçtan Uca Şifreleme</h3>
            <p>Mesajlarınız sadece siz ve alıcı tarafından okunabilir</p>
          </div>
          <div className="feature-card">
            <Wifi size={40} className="feature-icon" />
            <h3>Çoklu Bağlantı</h3>
            <p>Mobil veri, WiFi, Bluetooth ve Mesh desteği</p>
          </div>
          <div className="feature-card">
            <Smartphone size={40} className="feature-icon" />
            <h3>PWA Uygulama</h3>
            <p>Telefonunuza yükleyin, çevrimdışı kullanın</p>
          </div>
          <div className="feature-card">
            <Code size={40} className="feature-icon" />
            <h3>Bot Sistemi</h3>
            <p>Python veya JavaScript ile kendi botunuzu oluşturun</p>
          </div>
          <div className="feature-card">
            <MessageCircle size={40} className="feature-icon" />
            <h3>Sosyal Duvar</h3>
            <p>Paylaşım yapın, fotoğraf ve video paylaşın</p>
          </div>
        </div>
      </section>

      {/* Nasıl Çalışır */}
      <section className="how-it-works">
        <h2>Nasıl Çalışır?</h2>
        <div className="steps">
          <div className="step">
            <div className="step-number">1</div>
            <h4>Mobil Veri</h4>
            <p>Önce internet üzerinden dener</p>
          </div>
          <div className="step">
            <div className="step-number">2</div>
            <h4>WiFi Direct</h4>
            <p>İnternet yoksa WiFi ile aktarır</p>
          </div>
          <div className="step">
            <div className="step-number">3</div>
            <h4>Bluetooth</h4>
            <p>WiFi yoksa Bluetooth dener</p>
          </div>
          <div className="step">
            <div className="step-number">4</div>
            <h4>Mesh Ağı</h4>
            <p>Diğer telefonlar üzerinden iletir</p>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="cta">
        <h2>Hemen Başlayın</h2>
        <p>MeshChat'i kullanmaya başlayın ve her koşulda bağlı kalın.</p>
        <button className="btn-primary" onClick={() => navigate('/register')}>
          Ücretsiz Kaydol
        </button>
      </section>

      {/* Footer */}
      <footer className="footer">
        <p>&copy; 2024 MeshChat. Açık kaynak projesi.</p>
      </footer>
    </div>
  )
}

export default Landing
