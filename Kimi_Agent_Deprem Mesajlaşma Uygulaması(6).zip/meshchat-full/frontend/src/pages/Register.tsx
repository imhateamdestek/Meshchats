import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { Mail, Lock, User, MessageCircle } from 'lucide-react'
import './Auth.css'

function Register() {
  const navigate = useNavigate()
  const { login } = useAuth()
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    username: '',
    displayName: ''
  })
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')

    if (formData.password !== formData.confirmPassword) {
      setError('Şifreler eşleşmiyor')
      return
    }

    if (formData.password.length < 6) {
      setError('Şifre en az 6 karakter olmalı')
      return
    }

    setLoading(true)

    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: formData.email,
          password: formData.password,
          username: formData.username,
          displayName: formData.displayName,
          publicKey: ''
        })
      })

      const data = await response.json()

      if (data.success) {
        login(data.user, data.token)
        navigate('/chat')
      } else {
        setError(data.error || 'Kayıt başarısız')
      }
    } catch (err) {
      setError('Bağlantı hatası')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="auth-header">
          <div className="auth-logo">
            <MessageCircle size={40} />
          </div>
          <h1>MeshChat'e Katılın</h1>
          <p>Yeni bir hesap oluşturun</p>
        </div>

        <form onSubmit={handleSubmit}>
          {error && <div className="error-message">{error}</div>}

          <div className="form-group">
            <label>Ad Soyad</label>
            <div className="input-with-icon">
              <User size={20} />
              <input
                type="text"
                value={formData.displayName}
                onChange={(e) => setFormData({...formData, displayName: e.target.value})}
                placeholder="Ahmet Yılmaz"
                required
              />
            </div>
          </div>

          <div className="form-group">
            <label>Kullanıcı Adı</label>
            <div className="input-with-icon">
              <User size={20} />
              <input
                type="text"
                value={formData.username}
                onChange={(e) => setFormData({...formData, username: e.target.value})}
                placeholder="ahmetyilmaz"
                required
              />
            </div>
          </div>

          <div className="form-group">
            <label>E-posta</label>
            <div className="input-with-icon">
              <Mail size={20} />
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                placeholder="ornek@email.com"
                required
              />
            </div>
          </div>

          <div className="form-group">
            <label>Şifre</label>
            <div className="input-with-icon">
              <Lock size={20} />
              <input
                type="password"
                value={formData.password}
                onChange={(e) => setFormData({...formData, password: e.target.value})}
                placeholder="••••••••"
                required
              />
            </div>
          </div>

          <div className="form-group">
            <label>Şifre Tekrar</label>
            <div className="input-with-icon">
              <Lock size={20} />
              <input
                type="password"
                value={formData.confirmPassword}
                onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
                placeholder="••••••••"
                required
              />
            </div>
          </div>

          <button type="submit" className="btn-primary" disabled={loading}>
            {loading ? 'Kayıt yapılıyor...' : 'Kayıt Ol'}
          </button>
        </form>

        <div className="auth-footer">
          <p>Zaten hesabınız var mı? <a href="#/login">Giriş yapın</a></p>
        </div>
      </div>
    </div>
  )
}

export default Register
