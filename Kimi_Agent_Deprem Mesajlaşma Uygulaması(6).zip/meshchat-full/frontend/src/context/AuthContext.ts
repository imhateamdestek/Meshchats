import { createContext, useContext } from 'react'

interface AuthContextType {
  user: any
  token: string | null
  login: (user: any, token: string) => void
  logout: () => void
}

export const AuthContext = createContext<AuthContextType>({
  user: null,
  token: null,
  login: () => {},
  logout: () => {}
})

export const useAuth = () => useContext(AuthContext)
