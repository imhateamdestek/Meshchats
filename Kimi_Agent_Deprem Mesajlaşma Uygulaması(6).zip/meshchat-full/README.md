# MeshChat - Deprem Aninda Iletisim 🚨

> Internet olmadan bile calisan mesajlasma uygulamasi

## 🚀 Hizli Baslangic

### 1. Gereksinimler
- Node.js 18+ : https://nodejs.org

### 2. Kurulum

**Windows:**
```cmd
install.bat
```

**Linux/Mac:**
```bash
bash install.sh
```

### 3. Baslat

```bash
cd backend
npm start
```

**Site:** http://localhost:3000

**Admin:** admin@meshchat.com / admin123

---

## 🌐 Internete Acma (Render.com)

1. GitHub hesabi olustur: https://github.com
2. Yeni repo olustur: `meshchat`
3. Bu dosyalari GitHub'a yukle
4. Render.com'a git ve GitHub ile kaydol
5. "New Web Service" -> Repoyu sec
6. Ayarlar:
   - Build Command: `cd backend && npm install`
   - Start Command: `cd backend && npm start`
7. "Create Web Service"

**Hazir!** Site: `https://meshchat-xxx.onrender.com`

---

## 📱 Telefona Ykleme (PWA)

**Android (Chrome):**
1. Siteyi ac
2. Menu -> "Ana ekrana ekle"
3. "Ekle" de

**iPhone (Safari):**
1. Siteyi ac
2. Paylas -> "Ana Ekrana Ekle"
3. "Ekle" de

**Artik internet siz de calisir!** ✈️

---

## 📁 Proje Yapisi

```
meshchat-full/
├── backend/          # API + Veritabani
│   ├── server.js     # Ana sunucu
│   └── package.json
├── frontend/dist/    # Hazir site dosyalari
│   ├── index.html
│   └── assets/
├── install.sh        # Linux/Mac kurulum
├── install.bat       # Windows kurulum
└── README.md
```

---

## 💡 Ozellikler

- ✅ Tek komutla kurulum
- ✅ Otomatik veritabani (SQLite)
- ✅ Admin paneli
- ✅ Bot sistemi
- ✅ PWA (telefona yuklenebilir)
- ✅ Internet siz calisma

---

## 🆘 Sorun Cozumu

| Sorun | Cozum |
|-------|-------|
| "node bulunamadi" | Node.js yukle |
| Port hatasi | Baska program kapatin |
| Beyaz ekran | 5 dk bekle, F5 yap |

---

**Kolay gelsin!** 🎉
