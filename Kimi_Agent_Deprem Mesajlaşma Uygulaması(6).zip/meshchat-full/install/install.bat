@echo off
chcp 65001 >nul
cls

echo ╔════════════════════════════════════════════════════════════╗
echo ║                                                            ║
echo ║   🚀 MeshChat Otomatik Kurulum                            ║
echo ║                                                            ║
echo ╚════════════════════════════════════════════════════════════╝
echo.

:: Node.js kontrolü
echo 📦 Node.js kontrol ediliyor...
node --version >nul 2>&1
if errorlevel 1 (
    echo ❌ Node.js bulunamadı
    echo Lütfen Node.js'i yükleyin: https://nodejs.org/
    pause
    exit /b 1
)

echo ✅ Node.js bulundu

:: npm kontrolü
echo 📦 npm kontrol ediliyor...
npm --version >nul 2>&1
if errorlevel 1 (
    echo ❌ npm bulunamadı
    pause
    exit /b 1
)

echo ✅ npm bulundu

:: Backend kurulumu
echo.
echo 🔧 Backend kuruluyor...
cd ..\backend
echo 📥 Bağımlılıklar yükleniyor...
call npm install

:: .env dosyası oluştur
if not exist .env (
    echo ⚙️  .env dosyası oluşturuluyor...
    (
        echo # MeshChat Backend Ayarları
        echo PORT=3000
        echo JWT_SECRET=meshchat-super-secret-%RANDOM%%RANDOM%
        echo DB_PATH=./meshchat.db
        echo NODE_ENV=production
    ) > .env
)

echo ✅ Backend kuruldu

:: Frontend kurulumu
echo.
echo 🎨 Frontend kuruluyor...
cd ..\frontend
echo 📥 Bağımlılıklar yükleniyor...
call npm install

echo 🔨 Build alınıyor...
call npm run build

echo ✅ Frontend kuruldu

:: Başlatma scripti oluştur
echo.
echo 📝 Başlatma scripti oluşturuluyor...
cd ..
(
    echo @echo off
    echo chcp 65001 ^>nul
    echo cls
    echo.
    echo echo ╔════════════════════════════════════════════════════════════╗
    echo echo ║                                                            ║
    echo echo ║   🚀 MeshChat Başlatılıyor...                             ║
    echo echo ║                                                            ║
    echo echo ╚════════════════════════════════════════════════════════════╝
    echo echo.
    echo.
    echo echo 🔧 Backend başlatılıyor...
    echo start "MeshChat Backend" cmd /k "cd backend ^&^& npm start"
    echo.
    echo echo ⏳ Sunucu hazırlanıyor...
    echo timeout /t 3 /nobreak ^>nul
    echo.
    echo echo 🎨 Frontend başlatılıyor...
    echo start "MeshChat Frontend" cmd /k "cd frontend ^&^& npm run preview"
    echo.
    echo echo ╔════════════════════════════════════════════════════════════╗
    echo echo ║                                                            ║
    echo echo ║   ✅ MeshChat Çalışıyor!                                  ║
    echo echo ║                                                            ║
    echo echo ║   🌐 Uygulama: http://localhost:4173                      ║
    echo echo ║   🔌 API: http://localhost:3000                           ║
    echo echo ║                                                            ║
    echo echo ║   👤 Admin: admin@meshchat.com / admin123                 ║
    echo echo ║                                                            ║
    echo echo ╚════════════════════════════════════════════════════════════╝
    echo echo.
    echo pause
) > start.bat

echo ✅ start.bat oluşturuldu

echo.
echo ╔════════════════════════════════════════════════════════════╗
echo ║                                                            ║
echo ║   🎉 Kurulum Tamamlandı!                                  ║
echo ║                                                            ║
echo ║   Başlatmak için:                                         ║
echo ║   start.bat                                               ║
echo ║                                                            ║
echo ╚════════════════════════════════════════════════════════════╝
echo.

pause
