#!/bin/bash

# MeshChat Otomatik Kurulum Scripti
# Tek komutla tam kurulum: bash install.sh

set -e

echo "╔════════════════════════════════════════════════════════════╗"
echo "║                                                            ║"
echo "║   🚀 MeshChat Otomatik Kurulum                            ║"
echo "║                                                            ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""

# Renkler
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Node.js kontrolü
check_node() {
    echo -e "${BLUE}📦 Node.js kontrol ediliyor...${NC}"
    if command -v node &> /dev/null; then
        NODE_VERSION=$(node --version | cut -d'v' -f2 | cut -d'.' -f1)
        if [ "$NODE_VERSION" -ge 18 ]; then
            echo -e "${GREEN}✅ Node.js $(node --version) bulundu${NC}"
        else
            echo -e "${RED}❌ Node.js 18+ gereklidir. Mevcut: $(node --version)${NC}"
            echo "Lütfen Node.js'i güncelleyin: https://nodejs.org/"
            exit 1
        fi
    else
        echo -e "${RED}❌ Node.js bulunamadı${NC}"
        echo "Lütfen Node.js'i yükleyin: https://nodejs.org/"
        exit 1
    fi
}

# npm kontrolü
check_npm() {
    echo -e "${BLUE}📦 npm kontrol ediliyor...${NC}"
    if command -v npm &> /dev/null; then
        echo -e "${GREEN}✅ npm $(npm --version) bulundu${NC}"
    else
        echo -e "${RED}❌ npm bulunamadı${NC}"
        exit 1
    fi
}

# Backend kurulumu
install_backend() {
    echo ""
    echo -e "${YELLOW}🔧 Backend kuruluyor...${NC}"
    cd ../backend
    
    echo -e "${BLUE}📥 Bağımlılıklar yükleniyor...${NC}"
    npm install
    
    # .env dosyası oluştur
    if [ ! -f .env ]; then
        echo -e "${BLUE}⚙️  .env dosyası oluşturuluyor...${NC}"
        cat > .env << EOF
# MeshChat Backend Ayarları
PORT=3000
JWT_SECRET=meshchat-super-secret-$(openssl rand -hex 16)
DB_PATH=./meshchat.db
NODE_ENV=production
EOF
    fi
    
    echo -e "${GREEN}✅ Backend kuruldu${NC}"
    cd ..
}

# Frontend kurulumu
install_frontend() {
    echo ""
    echo -e "${YELLOW}🎨 Frontend kuruluyor...${NC}"
    cd frontend
    
    echo -e "${BLUE}📥 Bağımlılıklar yükleniyor...${NC}"
    npm install
    
    echo -e "${BLUE}🔨 Build alınıyor...${NC}"
    npm run build
    
    echo -e "${GREEN}✅ Frontend kuruldu${NC}"
    cd ..
}

# Başlatma scripti oluştur
create_start_script() {
    echo ""
    echo -e "${BLUE}📝 Başlatma scripti oluşturuluyor...${NC}"
    
    cat > start.sh << 'EOF'
#!/bin/bash

echo "╔════════════════════════════════════════════════════════════╗"
echo "║                                                            ║"
echo "║   🚀 MeshChat Başlatılıyor...                             ║"
echo "║                                                            ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""

# Backend'i arka planda başlat
cd backend
echo "🔧 Backend başlatılıyor..."
npm start &
BACKEND_PID=$!

# 3 saniye bekle
echo "⏳ Sunucu hazırlanıyor..."
sleep 3

# Frontend'i başlat
cd ../frontend
echo "🎨 Frontend başlatılıyor..."
npm run preview &
FRONTEND_PID=$!

echo ""
echo "╔════════════════════════════════════════════════════════════╗"
echo "║                                                            ║"
echo "║   ✅ MeshChat Çalışıyor!                                  ║"
echo "║                                                            ║"
echo "║   🌐 Uygulama: http://localhost:4173                      ║"
echo "║   🔌 API: http://localhost:3000                           ║"
echo "║                                                            ║"
echo "║   👤 Admin: admin@meshchat.com / admin123                 ║"
echo "║                                                            ║"
echo "║   Durdurmak için: Ctrl+C                                  ║"
echo "║                                                            ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""

# Ctrl+C ile durdurma
 trap "kill $BACKEND_PID $FRONTEND_PID; exit" INT

wait
EOF

    chmod +x start.sh
    echo -e "${GREEN}✅ start.sh oluşturuldu${NC}"
}

# Ana kurulum
main() {
    check_node
    check_npm
    install_backend
    install_frontend
    create_start_script
    
    echo ""
    echo "╔════════════════════════════════════════════════════════════╗"
    echo "║                                                            ║"
    echo "║   🎉 Kurulum Tamamlandı!                                  ║"
    echo "║                                                            ║"
    echo "║   Başlatmak için:                                         ║"
    echo "║   bash start.sh                                           ║"
    echo "║                                                            ║"
    echo "╚════════════════════════════════════════════════════════════╝"
    echo ""
}

main
