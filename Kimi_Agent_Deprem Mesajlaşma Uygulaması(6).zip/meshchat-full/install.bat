@echo off
chcp 65001 >nul
cls

echo ==================================
echo   MeshChat Kurulumu
echo ==================================
echo.

:: Node.js kontrol
node --version >nul 2>&1
if errorlevel 1 (
    echo ❌ Node.js bulunamadi!
    echo Lutfen once Node.js yukleyin: https://nodejs.org
    pause
    exit /b 1
)

echo ✅ Node.js bulundu
echo.

:: Backend kurulum
echo 🔧 Backend kuruluyor...
cd backend
call npm install
cd ..

:: JWT Secret olustur
if not exist backend\.env (
    echo JWT_SECRET=meshchat-%random%%random% > backend\.env
)

echo.
echo ==================================
echo   ✅ Kurulum Tamamlandi!
echo ==================================
echo.
echo Baslatmak icin:
echo   cd backend
echo   npm start
echo.
echo Site: http://localhost:3000
echo Admin: admin@meshchat.com / admin123
echo.

pause
