// MeshChat Service Worker
// Çevrimdışı çalışma ve arka plan senkronizasyonu

const CACHE_NAME = 'meshchat-v1';
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icons/icon-72x72.png',
  '/icons/icon-96x96.png',
  '/icons/icon-128x128.png',
  '/icons/icon-144x144.png',
  '/icons/icon-192x192.png',
  '/icons/icon-512x512.png',
];

// Yükleme Event'i
self.addEventListener('install', (event) => {
  console.log('[SW] Kuruluyor...');
  
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('[SW] Statik dosyalar önbelleğe alınıyor...');
        return cache.addAll(STATIC_ASSETS);
      })
      .then(() => {
        console.log('[SW] Kurulum tamamlandı');
        return self.skipWaiting();
      })
      .catch((error) => {
        console.error('[SW] Önbelleğe alma hatası:', error);
      })
  );
});

// Aktivasyon Event'i
self.addEventListener('activate', (event) => {
  console.log('[SW] Aktive ediliyor...');
  
  event.waitUntil(
    caches.keys()
      .then((cacheNames) => {
        return Promise.all(
          cacheNames
            .filter((name) => name !== CACHE_NAME)
            .map((name) => {
              console.log('[SW] Eski önbellek siliniyor:', name);
              return caches.delete(name);
            })
        );
      })
      .then(() => {
        console.log('[SW] Aktivasyon tamamlandı');
        return self.clients.claim();
      })
  );
});

// Fetch Event'i
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // API istekleri için ağ öncelikli strateji
  if (url.pathname.startsWith('/api/')) {
    event.respondWith(networkFirstStrategy(request));
    return;
  }

  // Statik dosyalar için önbellek öncelikli strateji
  if (request.method === 'GET') {
    event.respondWith(cacheFirstStrategy(request));
    return;
  }

  // Diğer istekler için ağ isteği
  event.respondWith(fetch(request));
});

// Önbellek Öncelikli Strateji
async function cacheFirstStrategy(request) {
  const cache = await caches.open(CACHE_NAME);
  const cached = await cache.match(request);

  if (cached) {
    // Arka planda güncelle
    fetch(request)
      .then((response) => {
        if (response.ok) {
          cache.put(request, response.clone());
        }
      })
      .catch(() => {});
    
    return cached;
  }

  try {
    const networkResponse = await fetch(request);
    if (networkResponse.ok) {
      cache.put(request, networkResponse.clone());
    }
    return networkResponse;
  } catch (error) {
    console.error('[SW] Ağ hatası:', error);
    // Çevrimdışı sayfa göster
    if (request.mode === 'navigate') {
      return cache.match('/offline.html');
    }
    throw error;
  }
}

// Ağ Öncelikli Strateji
async function networkFirstStrategy(request) {
  try {
    const networkResponse = await fetch(request);
    
    if (networkResponse.ok) {
      const cache = await caches.open(CACHE_NAME);
      cache.put(request, networkResponse.clone());
    }
    
    return networkResponse;
  } catch (error) {
    console.log('[SW] Ağ hatası, önbellek deneniyor...');
    
    const cache = await caches.open(CACHE_NAME);
    const cached = await cache.match(request);
    
    if (cached) {
      return cached;
    }
    
    // Bekleyen isteklere ekle
    await addToSyncQueue(request);
    
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: 'Çevrimdışı modda, istek sıraya alındı' 
      }),
      {
        status: 503,
        headers: { 'Content-Type': 'application/json' },
      }
    );
  }
}

// Senkronizasyon Kuyruğu
async function addToSyncQueue(request) {
  const db = await openDB('meshchat-sync', 1);
  const tx = db.transaction('sync-queue', 'readwrite');
  const store = tx.objectStore('sync-queue');
  
  await store.add({
    url: request.url,
    method: request.method,
    headers: Array.from(request.headers.entries()),
    body: await request.text(),
    timestamp: Date.now(),
  });
}

// IndexedDB Açma
function openDB(name, version) {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(name, version);
    
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
    
    request.onupgradeneeded = (event) => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains('sync-queue')) {
        db.createObjectStore('sync-queue', { keyPath: 'id', autoIncrement: true });
      }
    };
  });
}

// Arka Plan Senkronizasyonu
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-messages') {
    event.waitUntil(syncMessages());
  }
});

// Mesajları Senkronize Etme
async function syncMessages() {
  const db = await openDB('meshchat-sync', 1);
  const tx = db.transaction('sync-queue', 'readonly');
  const store = tx.objectStore('sync-queue');
  const requests = await store.getAll();
  
  for (const req of requests) {
    try {
      const response = await fetch(req.url, {
        method: req.method,
        headers: new Headers(req.headers),
        body: req.body,
      });
      
      if (response.ok) {
        // Başarılı isteği kuyruktan sil
        const deleteTx = db.transaction('sync-queue', 'readwrite');
        const deleteStore = deleteTx.objectStore('sync-queue');
        await deleteStore.delete(req.id);
      }
    } catch (error) {
      console.error('[SW] Senkronizasyon hatası:', error);
    }
  }
}

// Push Bildirimleri
self.addEventListener('push', (event) => {
  if (!event.data) return;
  
  const data = event.data.json();
  const options = {
    body: data.body,
    icon: '/icons/icon-192x192.png',
    badge: '/icons/badge-72x72.png',
    tag: data.tag,
    requireInteraction: true,
    actions: [
      {
        action: 'open',
        title: 'Aç',
      },
      {
        action: 'reply',
        title: 'Yanıtla',
      },
    ],
    data: data.data,
  };
  
  event.waitUntil(
    self.registration.showNotification(data.title, options)
  );
});

// Bildirim Tıklama
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  
  const { notification } = event;
  const { data } = notification;
  
  if (event.action === 'open' || event.action === 'reply') {
    event.waitUntil(
      clients.openWindow(`/chat/${data?.chatId || ''}`)
    );
  } else {
    event.waitUntil(
      clients.openWindow('/chat')
    );
  }
});

// Mesaj Event'i (Ana sayfa ile iletişim)
self.addEventListener('message', (event) => {
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
  }
  
  if (event.data.type === 'SYNC_NOW') {
    event.waitUntil(syncMessages());
  }
});

// Periyodik Senkronizasyon
self.addEventListener('periodicsync', (event) => {
  if (event.tag === 'periodic-sync') {
    event.waitUntil(syncMessages());
  }
});

// Bluetooth ve WebRTC için özel işleyiciler
self.addEventListener('message', (event) => {
  switch (event.data.type) {
    case 'BLUETOOTH_MESSAGE':
      // Bluetooth mesajını işle
      handleBluetoothMessage(event.data.payload);
      break;
      
    case 'WEBRTC_SIGNAL':
      // WebRTC sinyalini işle
      handleWebRTCSignal(event.data.payload);
      break;
      
    case 'MESH_FORWARD':
      // Mesh ağında mesajı ilet
      handleMeshForward(event.data.payload);
      break;
  }
});

async function handleBluetoothMessage(payload) {
  // Bluetooth mesaj işleme mantığı
  console.log('[SW] Bluetooth mesajı alındı:', payload);
}

async function handleWebRTCSignal(payload) {
  // WebRTC sinyal işleme mantığı
  console.log('[SW] WebRTC sinyali alındı:', payload);
}

async function handleMeshForward(payload) {
  // Mesh iletme mantığı
  console.log('[SW] Mesh iletme isteği:', payload);
  
  // Tüm istemcilere ilet
  const allClients = await clients.matchAll({ type: 'window' });
  allClients.forEach((client) => {
    client.postMessage({
      type: 'MESH_MESSAGE',
      payload: payload,
    });
  });
}

console.log('[SW] Service Worker yüklendi');
