// Mesh Ağ Servisi - Telefondan Telefona İletişim

import type { Message, MeshNode, NetworkStatus } from '@/types';
import { encryptionService } from './encryption';

interface PendingMessage {
  message: Message;
  attempts: number;
  lastAttempt: Date;
  triedNodes: Set<string>;
}

export class MeshNetworkService {
  private static instance: MeshNetworkService;
  private nodes: Map<string, MeshNode> = new Map();
  private pendingMessages: Map<string, PendingMessage> = new Map();
  private messageCallbacks: ((message: Message) => void)[] = [];
  private statusCallbacks: ((status: NetworkStatus) => void)[] = [];
  private bluetoothDevice: any | null = null;
  private bluetoothServer: any | null = null;
  private wifiPeer: RTCPeerConnection | null = null;
  private dataChannel: RTCDataChannel | null = null;
  private isInitialized = false;

  private constructor() {}

  static getInstance(): MeshNetworkService {
    if (!MeshNetworkService.instance) {
      MeshNetworkService.instance = new MeshNetworkService();
    }
    return MeshNetworkService.instance;
  }

  // Mesh Ağı Başlatma
  async initialize(): Promise<void> {
    if (this.isInitialized) return;

    // WebRTC'i başlat
    await this.initializeWebRTC();
    
    // Bluetooth'u başlat
    await this.initializeBluetooth();
    
    // Ağ durumunu dinle
    this.startNetworkMonitoring();
    
    this.isInitialized = true;
    console.log('Mesh ağı başlatıldı');
  }

  // WebRTC Başlatma
  private async initializeWebRTC(): Promise<void> {
    try {
      this.wifiPeer = new RTCPeerConnection({
        iceServers: [
          { urls: 'stun:stun.l.google.com:19302' },
          { urls: 'stun:stun1.l.google.com:19302' },
        ],
      });

      this.dataChannel = this.wifiPeer.createDataChannel('meshChat', {
        ordered: true,
      });

      this.dataChannel.onmessage = (event) => {
        this.handleIncomingMessage(event.data);
      };

      this.dataChannel.onopen = () => {
        console.log('WebRTC veri kanalı açıldı');
        this.updateNetworkStatus();
      };

      this.wifiPeer.onicecandidate = (event) => {
        if (event.candidate) {
          // ICE adayını mesh ağında yayınla
          this.broadcastICECandidate(event.candidate);
        }
      };

    } catch (error) {
      console.error('WebRTC başlatma hatası:', error);
    }
  }

  // Bluetooth Başlatma
  private async initializeBluetooth(): Promise<void> {
    try {
      if (!('bluetooth' in navigator)) {
        console.warn('Bluetooth API desteklenmiyor');
        return;
      }

      const bluetooth = (navigator as any).bluetooth;
      this.bluetoothDevice = await bluetooth.requestDevice({
        acceptAllDevices: true,
        optionalServices: ['battery_service', 'device_information'],
      });

      if (this.bluetoothDevice) {
        this.bluetoothDevice.addEventListener('gattserverdisconnected', () => {
          console.log('Bluetooth cihazı bağlantısı kesildi');
          this.updateNetworkStatus();
        });
      }

    } catch (error) {
      console.error('Bluetooth başlatma hatası:', error);
    }
  }

  // Bluetooth Bağlantısı
  async connectBluetooth(): Promise<boolean> {
    try {
      if (!this.bluetoothDevice) {
        await this.initializeBluetooth();
      }

      if (this.bluetoothDevice?.gatt) {
        this.bluetoothServer = await this.bluetoothDevice.gatt.connect();
        console.log('Bluetooth bağlantısı kuruldu');
        this.updateNetworkStatus();
        return true;
      }

      return false;
    } catch (error) {
      console.error('Bluetooth bağlantı hatası:', error);
      return false;
    }
  }

  // Ağ Durumunu İzleme
  private startNetworkMonitoring(): void {
    window.addEventListener('online', () => this.updateNetworkStatus());
    window.addEventListener('offline', () => this.updateNetworkStatus());
    
    // Periyodik olarak ağ durumunu kontrol et
    setInterval(() => this.updateNetworkStatus(), 5000);
  }

  // Ağ Durumunu Güncelleme
  private updateNetworkStatus(): void {
    const status: NetworkStatus = {
      isOnline: navigator.onLine,
      connectionType: this.getConnectionType(),
      signalStrength: this.getSignalStrength(),
      isMeshActive: this.isMeshActive(),
      connectedNodes: this.nodes.size,
      pendingMessages: this.pendingMessages.size,
    };

    this.statusCallbacks.forEach(callback => callback(status));
  }

  // Bağlantı Tipini Belirleme
  private getConnectionType(): 'none' | 'cellular' | 'wifi' | 'bluetooth' {
    if (!navigator.onLine) return 'none';
    
    const connection = (navigator as any).connection;
    if (connection) {
      if (connection.type === 'cellular') return 'cellular';
      if (connection.type === 'wifi') return 'wifi';
      if (connection.type === 'bluetooth') return 'bluetooth';
    }

    // Bluetooth bağlı mı kontrol et
    if (this.bluetoothServer?.connected) return 'bluetooth';
    
    // WebRTC bağlı mı kontrol et
    if (this.dataChannel?.readyState === 'open') return 'wifi';

    return navigator.onLine ? 'wifi' : 'none';
  }

  // Sinyal Gücünü Hesaplama
  private getSignalStrength(): number {
    const connection = (navigator as any).connection;
    if (connection?.effectiveType) {
      switch (connection.effectiveType) {
        case '4g': return 100;
        case '3g': return 75;
        case '2g': return 50;
        case 'slow-2g': return 25;
        default: return 50;
      }
    }
    return navigator.onLine ? 100 : 0;
  }

  // Mesh Aktif mi?
  private isMeshActive(): boolean {
    return this.nodes.size > 0 || 
           this.bluetoothServer?.connected || 
           this.dataChannel?.readyState === 'open';
  }

  // Mesaj Gönderme
  async sendMessage(message: Message): Promise<boolean> {
    // 1. İnternet ile dene
    if (navigator.onLine) {
      try {
        const success = await this.sendViaInternet(message);
        if (success) {
          message.deliveryMethod = 'internet';
          return true;
        }
      } catch (error) {
        console.log('İnternet gönderimi başarısız, alternatifler deneniyor...');
      }
    }

    // 2. WiFi Direct / WebRTC ile dene
    if (this.dataChannel?.readyState === 'open') {
      try {
        const success = await this.sendViaWebRTC(message);
        if (success) {
          message.deliveryMethod = 'wifi';
          return true;
        }
      } catch (error) {
        console.log('WiFi gönderimi başarısız...');
      }
    }

    // 3. Bluetooth ile dene
    if (this.bluetoothServer?.connected) {
      try {
        const success = await this.sendViaBluetooth(message);
        if (success) {
          message.deliveryMethod = 'bluetooth';
          return true;
        }
      } catch (error) {
        console.log('Bluetooth gönderimi başarısız...');
      }
    }

    // 4. Mesh ağında bir sonraki düğüme gönder
    const meshSuccess = await this.sendViaMesh(message);
    if (meshSuccess) {
      message.deliveryMethod = 'mesh';
      return true;
    }

    // 5. Bekleyen mesajlara ekle
    this.addToPendingMessages(message);
    return false;
  }

  // İnternet Üzerinden Gönderme
  private async sendViaInternet(message: Message): Promise<boolean> {
    try {
      const response = await fetch('/api/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(message),
      });
      return response.ok;
    } catch (error) {
      return false;
    }
  }

  // WebRTC Üzerinden Gönderme
  private async sendViaWebRTC(message: Message): Promise<boolean> {
    if (this.dataChannel?.readyState !== 'open') return false;

    try {
      const encrypted = await this.encryptMessageForMesh(message);
      this.dataChannel.send(JSON.stringify(encrypted));
      return true;
    } catch (error) {
      console.error('WebRTC gönderim hatası:', error);
      return false;
    }
  }

  // Bluetooth Üzerinden Gönderme
  private async sendViaBluetooth(message: Message): Promise<boolean> {
    if (!this.bluetoothServer?.connected) return false;

    try {
      const service = await this.bluetoothServer.getPrimaryService('device_information');
      const characteristic = await service.getCharacteristic('model_number_string');
      
      const encrypted = await this.encryptMessageForMesh(message);
      const encoder = new TextEncoder();
      await characteristic.writeValue(encoder.encode(JSON.stringify(encrypted)));
      
      return true;
    } catch (error) {
      console.error('Bluetooth gönderim hatası:', error);
      return false;
    }
  }

  // Mesh Ağı Üzerinden Gönderme
  private async sendViaMesh(message: Message): Promise<boolean> {
    // En yakın ve en güçlü sinyalli düğümü bul
    const bestNode = this.findBestRelayNode();
    if (!bestNode) return false;

    try {
      // Mesajı şifrele ve TTL'yi azalt
      message.ttl--;
      if (message.ttl <= 0) {
        console.log('Mesaj TTL süresi doldu');
        return false;
      }

      const encrypted = await this.encryptMessageForMesh(message);
      
      // Düğüme gönder
      await this.sendToNode(bestNode.id, encrypted);
      
      // Gönderilen düğümü kaydet
      const pending = this.pendingMessages.get(message.id);
      if (pending) {
        pending.triedNodes.add(bestNode.id);
      }

      return true;
    } catch (error) {
      console.error('Mesh gönderim hatası:', error);
      return false;
    }
  }

  // Mesh için Mesaj Şifreleme
  private async encryptMessageForMesh(message: Message): Promise<any> {
    const messageString = JSON.stringify(message);
    const hash = await encryptionService.hashData(messageString);
    
    return {
      type: 'mesh_message',
      messageId: message.id,
      senderId: message.senderId,
      receiverId: message.receiverId,
      content: message.encryptedContent || message.content,
      signature: message.signature,
      hash: hash,
      ttl: message.ttl,
      timestamp: message.timestamp,
    };
  }

  // Gelen Mesajı İşleme
  private async handleIncomingMessage(data: any): Promise<void> {
    try {
      const parsed = typeof data === 'string' ? JSON.parse(data) : data;
      
      if (parsed.type === 'mesh_message') {
        // Mesajın bize mi geldiğini kontrol et
        if (parsed.receiverId === this.getCurrentUserId()) {
          // Mesaj bize geldi, deşifre et ve göster
          this.messageCallbacks.forEach(callback => callback(parsed));
        } else {
          // Mesaj başkasına, mesh ağında ilet
          const message: Message = {
            ...parsed,
            timestamp: new Date(parsed.timestamp),
          };
          await this.sendViaMesh(message);
        }
      } else if (parsed.type === 'ice_candidate') {
        // ICE adayını işle
        await this.handleICECandidate(parsed.candidate);
      }
    } catch (error) {
      console.error('Gelen mesaj işleme hatası:', error);
    }
  }

  // En İyi Aktarım Düğümünü Bulma
  private findBestRelayNode(): MeshNode | null {
    let bestNode: MeshNode | null = null;
    let bestScore = 0;

    this.nodes.forEach(node => {
      const score = node.signalStrength * (1 / (node.hops + 1));
      if (score > bestScore && node.isRelay) {
        bestScore = score;
        bestNode = node;
      }
    });

    return bestNode;
  }

  // Düğüme Mesaj Gönderme
  private async sendToNode(nodeId: string, _data: any): Promise<void> {
    // WebRTC veya Bluetooth üzerinden düğüme gönder
    console.log(`Mesaj ${nodeId} düğümüne gönderildi`);
  }

  // ICE Adayını Yayınlama
  private broadcastICECandidate(_candidate: RTCIceCandidate): void {
    const message = {
      type: 'ice_candidate',
      candidate: _candidate.toJSON(),
    };
    // Mesh ağında yayınla
    console.log('ICE adayı yayınlandı:', message);
  }

  // ICE Adayını İşleme
  private async handleICECandidate(candidateData: any): Promise<void> {
    if (this.wifiPeer) {
      await this.wifiPeer.addIceCandidate(new RTCIceCandidate(candidateData));
    }
  }

  // Bekleyen Mesajlara Ekleme
  private addToPendingMessages(message: Message): void {
    this.pendingMessages.set(message.id, {
      message,
      attempts: 0,
      lastAttempt: new Date(),
      triedNodes: new Set(),
    });
  }

  // Bekleyen Mesajları Tekrar Dene
  async retryPendingMessages(): Promise<void> {
    const now = new Date();
    
    for (const [id, pending] of this.pendingMessages) {
      // 30 saniyeden eski mesajları tekrar dene
      if (now.getTime() - pending.lastAttempt.getTime() > 30000) {
        pending.attempts++;
        
        if (pending.attempts > 10) {
          // Çok fazla deneme, mesajı sil
          this.pendingMessages.delete(id);
          console.log(`Mesaj ${id} çok fazla deneme sonrası silindi`);
        } else {
          pending.lastAttempt = now;
          await this.sendMessage(pending.message);
        }
      }
    }
  }

  // Yeni Düğüm Ekleme
  addNode(node: MeshNode): void {
    this.nodes.set(node.id, node);
    this.updateNetworkStatus();
  }

  // Düğüm Kaldırma
  removeNode(nodeId: string): void {
    this.nodes.delete(nodeId);
    this.updateNetworkStatus();
  }

  // Mesaj Callback'i Ekleme
  onMessage(callback: (message: Message) => void): void {
    this.messageCallbacks.push(callback);
  }

  // Durum Callback'i Ekleme
  onStatusChange(callback: (status: NetworkStatus) => void): void {
    this.statusCallbacks.push(callback);
  }

  // Mevcut Kullanıcı ID'sini Alma
  private getCurrentUserId(): string {
    // Auth context'ten alınacak
    return localStorage.getItem('userId') || '';
  }

  // Mesh Ağını Durdurma
  stop(): void {
    this.dataChannel?.close();
    this.wifiPeer?.close();
    this.bluetoothServer?.disconnect();
    this.isInitialized = false;
    console.log('Mesh ağı durduruldu');
  }
}

export const meshNetwork = MeshNetworkService.getInstance();
