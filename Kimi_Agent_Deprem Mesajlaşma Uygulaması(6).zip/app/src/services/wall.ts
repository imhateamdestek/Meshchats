// Duvar Servisi - Kullanıcı Paylaşımları

import type { WallPost, Comment, ApiResponse } from '@/types';
import { authService } from './auth';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000/api';

export class WallService {
  private static instance: WallService;
  private posts: Map<string, WallPost> = new Map();
  private userPosts: Map<string, string[]> = new Map();
  private postCallbacks: ((post: WallPost) => void)[] = [];

  private constructor() {}

  static getInstance(): WallService {
    if (!WallService.instance) {
      WallService.instance = new WallService();
    }
    return WallService.instance;
  }

  // Yeni Paylaşım Oluşturma
  async createPost(
    content: string,
    mediaUrls: string[] = [],
    mediaType: 'image' | 'video' | 'none' = 'none',
    taggedUsers: string[] = []
  ): Promise<ApiResponse<WallPost>> {
    try {
      const currentUser = authService.getCurrentUser();
      if (!currentUser) {
        return { success: false, error: 'Oturum açık değil' };
      }

      const response = await fetch(`${API_BASE_URL}/wall/posts`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authService.getToken()}`,
        },
        body: JSON.stringify({
          content,
          mediaUrls,
          mediaType,
          taggedUsers,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        const post = data.post;
        this.posts.set(post.id, post);
        
        // Kullanıcının paylaşımlarına ekle
        const userPostList = this.userPosts.get(currentUser.id) || [];
        userPostList.unshift(post.id);
        this.userPosts.set(currentUser.id, userPostList);

        // Etiketlenen kullanıcılara bildirim gönder
        await this.notifyTaggedUsers(post);

        this.postCallbacks.forEach(callback => callback(post));
        return { success: true, data: post };
      } else {
        return { success: false, error: data.error || 'Paylaşım oluşturulamadı' };
      }
    } catch (error) {
      console.error('Paylaşım oluşturma hatası:', error);
      return { success: false, error: 'Bağlantı hatası' };
    }
  }

  // Etiketlenen Kullanıcılara Bildirim
  private async notifyTaggedUsers(post: WallPost): Promise<void> {
    for (const userId of post.taggedUsers) {
      try {
        await fetch(`${API_BASE_URL}/notifications`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${authService.getToken()}`,
          },
          body: JSON.stringify({
            type: 'tag',
            recipientId: userId,
            postId: post.id,
            message: `Bir gönderide etiketlendiniz`,
          }),
        });
      } catch (error) {
        console.error('Bildirim gönderme hatası:', error);
      }
    }
  }

  // Kullanıcının Duvarını Getirme
  async getUserWall(userId: string, limit = 20, offset = 0): Promise<ApiResponse<WallPost[]>> {
    try {
      const response = await fetch(
        `${API_BASE_URL}/wall/users/${userId}/posts?limit=${limit}&offset=${offset}`,
        {
          headers: {
            'Authorization': `Bearer ${authService.getToken()}`,
          },
        }
      );

      if (response.ok) {
        const data = await response.json();
        const posts = data.posts;

        // Postları cache'e ekle
        posts.forEach((post: WallPost) => {
          this.posts.set(post.id, post);
        });

        // Kullanıcı postlarını güncelle
        const postIds = posts.map((p: WallPost) => p.id);
        this.userPosts.set(userId, postIds);

        return { success: true, data: posts };
      } else {
        return { success: false, error: 'Paylaşımlar alınamadı' };
      }
    } catch (error) {
      return { success: false, error: 'Bağlantı hatası' };
    }
  }

  // Ana Sayfa Akışını Getirme
  async getFeed(limit = 20, offset = 0): Promise<ApiResponse<WallPost[]>> {
    try {
      const response = await fetch(
        `${API_BASE_URL}/wall/feed?limit=${limit}&offset=${offset}`,
        {
          headers: {
            'Authorization': `Bearer ${authService.getToken()}`,
          },
        }
      );

      if (response.ok) {
        const data = await response.json();
        const posts = data.posts;

        posts.forEach((post: WallPost) => {
          this.posts.set(post.id, post);
        });

        return { success: true, data: posts };
      } else {
        return { success: false, error: 'Akış alınamadı' };
      }
    } catch (error) {
      return { success: false, error: 'Bağlantı hatası' };
    }
  }

  // Paylaşımı Getirme
  async getPost(postId: string): Promise<ApiResponse<WallPost>> {
    // Önce cache'den kontrol et
    const cachedPost = this.posts.get(postId);
    if (cachedPost) {
      return { success: true, data: cachedPost };
    }

    try {
      const response = await fetch(`${API_BASE_URL}/wall/posts/${postId}`, {
        headers: {
          'Authorization': `Bearer ${authService.getToken()}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        this.posts.set(postId, data.post);
        return { success: true, data: data.post };
      } else {
        return { success: false, error: 'Paylaşım bulunamadı' };
      }
    } catch (error) {
      return { success: false, error: 'Bağlantı hatası' };
    }
  }

  // Paylaşımı Silme
  async deletePost(postId: string): Promise<ApiResponse<void>> {
    try {
      const currentUser = authService.getCurrentUser();
      if (!currentUser) {
        return { success: false, error: 'Oturum açık değil' };
      }

      const post = this.posts.get(postId);
      if (post && post.userId !== currentUser.id) {
        return { success: false, error: 'Bu paylaşımı silme yetkiniz yok' };
      }

      const response = await fetch(`${API_BASE_URL}/wall/posts/${postId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${authService.getToken()}`,
        },
      });

      if (response.ok) {
        this.posts.delete(postId);
        
        // Kullanıcı postlarından kaldır
        const userPosts = this.userPosts.get(currentUser.id) || [];
        const index = userPosts.indexOf(postId);
        if (index > -1) {
          userPosts.splice(index, 1);
        }

        return { success: true, message: 'Paylaşım silindi' };
      } else {
        return { success: false, error: 'Paylaşım silinemedi' };
      }
    } catch (error) {
      return { success: false, error: 'Bağlantı hatası' };
    }
  }

  // Paylaşımı Düzenleme
  async editPost(postId: string, content: string): Promise<ApiResponse<WallPost>> {
    try {
      const currentUser = authService.getCurrentUser();
      if (!currentUser) {
        return { success: false, error: 'Oturum açık değil' };
      }

      const post = this.posts.get(postId);
      if (post && post.userId !== currentUser.id) {
        return { success: false, error: 'Bu paylaşımı düzenleme yetkiniz yok' };
      }

      const response = await fetch(`${API_BASE_URL}/wall/posts/${postId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authService.getToken()}`,
        },
        body: JSON.stringify({ content }),
      });

      if (response.ok) {
        const data = await response.json();
        this.posts.set(postId, data.post);
        this.postCallbacks.forEach(callback => callback(data.post));
        return { success: true, data: data.post };
      } else {
        return { success: false, error: 'Paylaşım düzenlenemedi' };
      }
    } catch (error) {
      return { success: false, error: 'Bağlantı hatası' };
    }
  }

  // Beğenme
  async likePost(postId: string): Promise<ApiResponse<void>> {
    try {
      const response = await fetch(`${API_BASE_URL}/wall/posts/${postId}/like`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${authService.getToken()}`,
        },
      });

      if (response.ok) {
        const post = this.posts.get(postId);
        if (post) {
          post.likes++;
          this.posts.set(postId, post);
        }
        return { success: true, message: 'Beğenildi' };
      } else {
        return { success: false, error: 'İşlem başarısız' };
      }
    } catch (error) {
      return { success: false, error: 'Bağlantı hatası' };
    }
  }

  // Beğeniyi Kaldırma
  async unlikePost(postId: string): Promise<ApiResponse<void>> {
    try {
      const response = await fetch(`${API_BASE_URL}/wall/posts/${postId}/unlike`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${authService.getToken()}`,
        },
      });

      if (response.ok) {
        const post = this.posts.get(postId);
        if (post && post.likes > 0) {
          post.likes--;
          this.posts.set(postId, post);
        }
        return { success: true, message: 'Beğeni kaldırıldı' };
      } else {
        return { success: false, error: 'İşlem başarısız' };
      }
    } catch (error) {
      return { success: false, error: 'Bağlantı hatası' };
    }
  }

  // Yorum Ekleme
  async addComment(postId: string, content: string): Promise<ApiResponse<Comment>> {
    try {
      const response = await fetch(`${API_BASE_URL}/wall/posts/${postId}/comments`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authService.getToken()}`,
        },
        body: JSON.stringify({ content }),
      });

      if (response.ok) {
        const data = await response.json();
        const post = this.posts.get(postId);
        if (post) {
          post.comments.push(data.comment);
          this.posts.set(postId, post);
        }
        return { success: true, data: data.comment };
      } else {
        return { success: false, error: 'Yorum eklenemedi' };
      }
    } catch (error) {
      return { success: false, error: 'Bağlantı hatası' };
    }
  }

  // Yorum Silme
  async deleteComment(postId: string, commentId: string): Promise<ApiResponse<void>> {
    try {
      const response = await fetch(
        `${API_BASE_URL}/wall/posts/${postId}/comments/${commentId}`,
        {
          method: 'DELETE',
          headers: {
            'Authorization': `Bearer ${authService.getToken()}`,
          },
        }
      );

      if (response.ok) {
        const post = this.posts.get(postId);
        if (post) {
          post.comments = post.comments.filter(c => c.id !== commentId);
          this.posts.set(postId, post);
        }
        return { success: true, message: 'Yorum silindi' };
      } else {
        return { success: false, error: 'Yorum silinemedi' };
      }
    } catch (error) {
      return { success: false, error: 'Bağlantı hatası' };
    }
  }

  // Medya Yükleme
  async uploadMedia(file: File): Promise<ApiResponse<string>> {
    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch(`${API_BASE_URL}/wall/upload`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${authService.getToken()}`,
        },
        body: formData,
      });

      if (response.ok) {
        const data = await response.json();
        return { success: true, data: data.url };
      } else {
        return { success: false, error: 'Yükleme başarısız' };
      }
    } catch (error) {
      return { success: false, error: 'Bağlantı hatası' };
    }
  }

  // Paylaşım Dinleyici Ekleme
  onPostUpdate(callback: (post: WallPost) => void): () => void {
    this.postCallbacks.push(callback);
    return () => {
      const index = this.postCallbacks.indexOf(callback);
      if (index > -1) {
        this.postCallbacks.splice(index, 1);
      }
    };
  }

  // Kullanıcının Paylaşım Sayısını Getirme
  getUserPostCount(userId: string): number {
    return this.userPosts.get(userId)?.length || 0;
  }

  // Paylaşımı Raporlama
  async reportPost(postId: string, reason: string): Promise<ApiResponse<void>> {
    try {
      const response = await fetch(`${API_BASE_URL}/wall/posts/${postId}/report`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authService.getToken()}`,
        },
        body: JSON.stringify({ reason }),
      });

      if (response.ok) {
        return { success: true, message: 'Rapor gönderildi' };
      } else {
        return { success: false, error: 'Rapor gönderilemedi' };
      }
    } catch (error) {
      return { success: false, error: 'Bağlantı hatası' };
    }
  }
}

export const wallService = WallService.getInstance();
