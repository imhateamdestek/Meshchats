// Şifreleme Servisi - End-to-End Encryption

export class EncryptionService {
  private static instance: EncryptionService;
  private keyPair: CryptoKeyPair | null = null;
  private symmetricKey: CryptoKey | null = null;

  private constructor() {}

  static getInstance(): EncryptionService {
    if (!EncryptionService.instance) {
      EncryptionService.instance = new EncryptionService();
    }
    return EncryptionService.instance;
  }

  // RSA Anahtar Çifti Oluşturma
  async generateKeyPair(): Promise<CryptoKeyPair> {
    const keyPair = await window.crypto.subtle.generateKey(
      {
        name: 'RSA-OAEP',
        modulusLength: 4096,
        publicExponent: new Uint8Array([1, 0, 1]),
        hash: 'SHA-256',
      },
      true,
      ['encrypt', 'decrypt']
    );
    this.keyPair = keyPair;
    return keyPair;
  }

  // Simetrik Anahtar Oluşturma (AES-GCM)
  async generateSymmetricKey(): Promise<CryptoKey> {
    const key = await window.crypto.subtle.generateKey(
      {
        name: 'AES-GCM',
        length: 256,
      },
      true,
      ['encrypt', 'decrypt']
    );
    this.symmetricKey = key;
    return key;
  }

  // Anahtarları Getir
  getKeyPair(): CryptoKeyPair | null {
    return this.keyPair;
  }

  getSymmetricKey(): CryptoKey | null {
    return this.symmetricKey;
  }

  // Mesaj Şifreleme
  async encryptMessage(message: string, publicKey: CryptoKey): Promise<string> {
    const encoder = new TextEncoder();
    const data = encoder.encode(message);
    
    const encrypted = await window.crypto.subtle.encrypt(
      {
        name: 'RSA-OAEP',
      },
      publicKey,
      data
    );
    
    return this.arrayBufferToBase64(encrypted);
  }

  // Mesaj Deşifreleme
  async decryptMessage(encryptedMessage: string, privateKey: CryptoKey): Promise<string> {
    const decoder = new TextDecoder();
    const encrypted = this.base64ToArrayBuffer(encryptedMessage);
    
    const decrypted = await window.crypto.subtle.decrypt(
      {
        name: 'RSA-OAEP',
      },
      privateKey,
      encrypted
    );
    
    return decoder.decode(decrypted);
  }

  // Hızlı şifreleme için AES-GCM
  async encryptWithAES(message: string, key: CryptoKey): Promise<{ encrypted: string; iv: string }> {
    const encoder = new TextEncoder();
    const iv = window.crypto.getRandomValues(new Uint8Array(12));
    
    const encrypted = await window.crypto.subtle.encrypt(
      {
        name: 'AES-GCM',
        iv: iv.buffer,
      },
      key,
      encoder.encode(message)
    );
    
    return {
      encrypted: this.arrayBufferToBase64(encrypted),
      iv: this.arrayBufferToBase64(iv.buffer),
    };
  }

  // AES Deşifreleme
  async decryptWithAES(encrypted: string, iv: string, key: CryptoKey): Promise<string> {
    const decoder = new TextDecoder();
    const encryptedData = this.base64ToArrayBuffer(encrypted);
    const ivData = this.base64ToArrayBuffer(iv);
    
    const decrypted = await window.crypto.subtle.decrypt(
      {
        name: 'AES-GCM',
        iv: ivData,
      },
      key,
      encryptedData
    );
    
    return decoder.decode(decrypted);
  }

  // Dijital İmza Oluşturma
  async signMessage(message: string, privateKey: CryptoKey): Promise<string> {
    const encoder = new TextEncoder();
    const signature = await window.crypto.subtle.sign(
      {
        name: 'RSA-PSS',
        saltLength: 32,
      },
      privateKey,
      encoder.encode(message)
    );
    
    return this.arrayBufferToBase64(signature);
  }

  // İmza Doğrulama
  async verifySignature(message: string, signature: string, publicKey: CryptoKey): Promise<boolean> {
    const encoder = new TextEncoder();
    const signatureData = this.base64ToArrayBuffer(signature);
    
    return await window.crypto.subtle.verify(
      {
        name: 'RSA-PSS',
        saltLength: 32,
      },
      publicKey,
      signatureData,
      encoder.encode(message)
    );
  }

  // Anahtarı Base64'e Çevirme
  async exportPublicKey(key: CryptoKey): Promise<string> {
    const exported = await window.crypto.subtle.exportKey('spki', key);
    return this.arrayBufferToBase64(exported);
  }

  // Base64'ten Anahtar İçe Aktarma
  async importPublicKey(keyData: string): Promise<CryptoKey> {
    const binary = this.base64ToArrayBuffer(keyData);
    return await window.crypto.subtle.importKey(
      'spki',
      binary,
      {
        name: 'RSA-OAEP',
        hash: 'SHA-256',
      },
      true,
      ['encrypt']
    );
  }

  // Özel Anahtarı İçe Aktarma
  async importPrivateKey(keyData: string): Promise<CryptoKey> {
    const binary = this.base64ToArrayBuffer(keyData);
    return await window.crypto.subtle.importKey(
      'pkcs8',
      binary,
      {
        name: 'RSA-OAEP',
        hash: 'SHA-256',
      },
      true,
      ['decrypt']
    );
  }

  // Yardımcı Fonksiyonlar
  private arrayBufferToBase64(buffer: ArrayBuffer): string {
    const bytes = new Uint8Array(buffer);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
  }

  private base64ToArrayBuffer(base64: string): ArrayBuffer {
    const binary = window.atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return bytes.buffer;
  }

  // Hash Oluşturma
  async hashData(data: string): Promise<string> {
    const encoder = new TextEncoder();
    const hash = await window.crypto.subtle.digest('SHA-256', encoder.encode(data));
    return this.arrayBufferToBase64(hash);
  }
}

export const encryptionService = EncryptionService.getInstance();
