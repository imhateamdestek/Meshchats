// Kimlik Doğrulama Servisi

import type { User, AuthState, ApiResponse } from '@/types';
import { encryptionService } from './encryption';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000/api';

export class AuthService {
  private static instance: AuthService;
  private currentUser: User | null = null;
  private authState: AuthState = {
    isAuthenticated: false,
    user: null,
    token: null,
    refreshToken: null,
  };
  private authCallbacks: ((state: AuthState) => void)[] = [];

  private constructor() {
    this.loadStoredAuth();
  }

  static getInstance(): AuthService {
    if (!AuthService.instance) {
      AuthService.instance = new AuthService();
    }
    return AuthService.instance;
  }

  // Kayıtlı Kimlik Bilgilerini Yükleme
  private loadStoredAuth(): void {
    const stored = localStorage.getItem('authState');
    if (stored) {
      try {
        this.authState = JSON.parse(stored);
        if (this.authState.token) {
          this.validateToken();
        }
      } catch (error) {
        console.error('Kimlik bilgileri yüklenirken hata:', error);
        this.logout();
      }
    }
  }

  // Token Doğrulama
  private async validateToken(): Promise<void> {
    try {
      const response = await fetch(`${API_BASE_URL}/auth/validate`, {
        headers: {
          'Authorization': `Bearer ${this.authState.token}`,
        },
      });

      if (!response.ok) {
        // Token geçersiz, yenilemeyi dene
        await this.refreshAccessToken();
      } else {
        const data = await response.json();
        this.currentUser = data.user;
        this.authState.user = data.user;
        this.authState.isAuthenticated = true;
        this.notifyAuthChange();
      }
    } catch (error) {
      console.error('Token doğrulama hatası:', error);
      this.logout();
    }
  }

  // Token Yenileme
  private async refreshAccessToken(): Promise<void> {
    try {
      const response = await fetch(`${API_BASE_URL}/auth/refresh`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refreshToken: this.authState.refreshToken }),
      });

      if (response.ok) {
        const data = await response.json();
        this.authState.token = data.token;
        this.authState.refreshToken = data.refreshToken;
        this.saveAuthState();
        this.validateToken();
      } else {
        this.logout();
      }
    } catch (error) {
      console.error('Token yenileme hatası:', error);
      this.logout();
    }
  }

  // E-posta ile Giriş
  async loginWithEmail(email: string, password: string): Promise<ApiResponse<User>> {
    try {
      const response = await fetch(`${API_BASE_URL}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      const data = await response.json();

      if (response.ok) {
        // Şifreleme anahtarlarını oluştur
        await encryptionService.generateKeyPair();
        await encryptionService.generateSymmetricKey();

        this.authState = {
          isAuthenticated: true,
          user: data.user,
          token: data.token,
          refreshToken: data.refreshToken,
        };
        this.currentUser = data.user;
        this.saveAuthState();
        this.notifyAuthChange();

        return { success: true, data: data.user };
      } else {
        return { success: false, error: data.error || 'Giriş başarısız' };
      }
    } catch (error) {
      console.error('Giriş hatası:', error);
      return { success: false, error: 'Bağlantı hatası' };
    }
  }

  // E-posta ile Kayıt
  async registerWithEmail(
    email: string,
    password: string,
    username: string,
    displayName: string
  ): Promise<ApiResponse<User>> {
    try {
      // Kullanıcı adı kontrolü
      const usernameCheck = await this.checkUsernameAvailability(username);
      if (!usernameCheck.available) {
        return { success: false, error: 'Kullanıcı adı zaten kullanımda' };
      }

      // Şifre güçlülük kontrolü
      if (!this.isPasswordStrong(password)) {
        return { 
          success: false, 
          error: 'Şifre en az 8 karakter, bir büyük harf, bir küçük harf ve bir rakam içermelidir' 
        };
      }

      // Şifreleme anahtarlarını oluştur
      const keyPair = await encryptionService.generateKeyPair();
      const publicKey = await encryptionService.exportPublicKey(keyPair.publicKey);

      const response = await fetch(`${API_BASE_URL}/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email,
          password,
          username,
          displayName,
          publicKey,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        this.authState = {
          isAuthenticated: true,
          user: data.user,
          token: data.token,
          refreshToken: data.refreshToken,
        };
        this.currentUser = data.user;
        this.saveAuthState();
        this.notifyAuthChange();

        return { success: true, data: data.user };
      } else {
        return { success: false, error: data.error || 'Kayıt başarısız' };
      }
    } catch (error) {
      console.error('Kayıt hatası:', error);
      return { success: false, error: 'Bağlantı hatası' };
    }
  }

  // Kullanıcı Adı Kullanılabilirlik Kontrolü
  async checkUsernameAvailability(username: string): Promise<{ available: boolean }> {
    try {
      const response = await fetch(`${API_BASE_URL}/auth/check-username?username=${username}`);
      const data = await response.json();
      return { available: data.available };
    } catch (error) {
      return { available: false };
    }
  }

  // Şifre Güçlülük Kontrolü
  private isPasswordStrong(password: string): boolean {
    const minLength = 8;
    const hasUpperCase = /[A-Z]/.test(password);
    const hasLowerCase = /[a-z]/.test(password);
    const hasNumbers = /\d/.test(password);
    const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);

    return (
      password.length >= minLength &&
      hasUpperCase &&
      hasLowerCase &&
      hasNumbers &&
      hasSpecialChar
    );
  }

  // Şifre Sıfırlama İsteği
  async requestPasswordReset(email: string): Promise<ApiResponse<void>> {
    try {
      const response = await fetch(`${API_BASE_URL}/auth/reset-password`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });

      if (response.ok) {
        return { success: true, message: 'Şifre sıfırlama bağlantısı e-posta adresinize gönderildi' };
      } else {
        return { success: false, error: 'E-posta adresi bulunamadı' };
      }
    } catch (error) {
      return { success: false, error: 'Bağlantı hatası' };
    }
  }

  // Çıkış
  logout(): void {
    this.authState = {
      isAuthenticated: false,
      user: null,
      token: null,
      refreshToken: null,
    };
    this.currentUser = null;
    localStorage.removeItem('authState');
    localStorage.removeItem('userId');
    this.notifyAuthChange();
  }

  // Kimlik Doğrulama Durumunu Kaydetme
  private saveAuthState(): void {
    localStorage.setItem('authState', JSON.stringify(this.authState));
    if (this.currentUser) {
      localStorage.setItem('userId', this.currentUser.id);
    }
  }

  // Kimlik Doğrulama Değişiklik Bildirimi
  private notifyAuthChange(): void {
    this.authCallbacks.forEach(callback => callback(this.authState));
  }

  // Kimlik Doğrulama Değişiklik Dinleyici
  onAuthChange(callback: (state: AuthState) => void): () => void {
    this.authCallbacks.push(callback);
    return () => {
      const index = this.authCallbacks.indexOf(callback);
      if (index > -1) {
        this.authCallbacks.splice(index, 1);
      }
    };
  }

  // Mevcut Kullanıcıyı Alma
  getCurrentUser(): User | null {
    return this.currentUser;
  }

  // Kimlik Doğrulama Durumunu Alma
  getAuthState(): AuthState {
    return this.authState;
  }

  // Token Alma
  getToken(): string | null {
    return this.authState.token;
  }

  // Kimlik Doğrulama Kontrolü
  isAuthenticated(): boolean {
    return this.authState.isAuthenticated;
  }

  // Profil Güncelleme
  async updateProfile(updates: Partial<User>): Promise<ApiResponse<User>> {
    try {
      const response = await fetch(`${API_BASE_URL}/users/profile`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.authState.token}`,
        },
        body: JSON.stringify(updates),
      });

      const data = await response.json();

      if (response.ok) {
        this.currentUser = { ...this.currentUser!, ...data.user };
        this.authState.user = this.currentUser;
        this.saveAuthState();
        this.notifyAuthChange();
        return { success: true, data: this.currentUser! };
      } else {
        return { success: false, error: data.error };
      }
    } catch (error) {
      return { success: false, error: 'Bağlantı hatası' };
    }
  }

  // Şifre Değiştirme
  async changePassword(currentPassword: string, newPassword: string): Promise<ApiResponse<void>> {
    try {
      if (!this.isPasswordStrong(newPassword)) {
        return { 
          success: false, 
          error: 'Yeni şifre güvenlik gereksinimlerini karşılamıyor' 
        };
      }

      const response = await fetch(`${API_BASE_URL}/auth/change-password`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.authState.token}`,
        },
        body: JSON.stringify({ currentPassword, newPassword }),
      });

      if (response.ok) {
        return { success: true, message: 'Şifre başarıyla değiştirildi' };
      } else {
        const data = await response.json();
        return { success: false, error: data.error || 'Şifre değiştirme başarısız' };
      }
    } catch (error) {
      return { success: false, error: 'Bağlantı hatası' };
    }
  }

  // Hesap Silme
  async deleteAccount(password: string): Promise<ApiResponse<void>> {
    try {
      const response = await fetch(`${API_BASE_URL}/auth/delete-account`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.authState.token}`,
        },
        body: JSON.stringify({ password }),
      });

      if (response.ok) {
        this.logout();
        return { success: true, message: 'Hesap başarıyla silindi' };
      } else {
        const data = await response.json();
        return { success: false, error: data.error || 'Hesap silme başarısız' };
      }
    } catch (error) {
      return { success: false, error: 'Bağlantı hatası' };
    }
  }
}

export const authService = AuthService.getInstance();
