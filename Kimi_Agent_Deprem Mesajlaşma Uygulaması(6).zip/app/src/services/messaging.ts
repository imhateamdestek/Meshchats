// Mesajlaşma Servisi

import type { Message, Chat, ApiResponse } from '@/types';
import { encryptionService } from './encryption';
import { meshNetwork } from './meshNetwork';
import { authService } from './auth';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000/api';

export class MessagingService {
  private static instance: MessagingService;
  private chats: Map<string, Chat> = new Map();
  private messages: Map<string, Message> = new Map();
  private messageCallbacks: ((message: Message) => void)[] = [];
  private chatUpdateCallbacks: ((chat: Chat) => void)[] = [];
  private socket: WebSocket | null = null;
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 5;

  private constructor() {
    this.initializeWebSocket();
    this.setupMeshListener();
  }

  static getInstance(): MessagingService {
    if (!MessagingService.instance) {
      MessagingService.instance = new MessagingService();
    }
    return MessagingService.instance;
  }
  
  // WebSocket Bağlantısı
  private initializeWebSocket(): void {
    const token = authService.getToken();
    if (!token) return;

    const wsUrl = API_BASE_URL.replace('http', 'ws') + '/ws';
    this.socket = new WebSocket(`${wsUrl}?token=${token}`);

    this.socket.onopen = () => {
      console.log('WebSocket bağlantısı kuruldu');
      this.reconnectAttempts = 0;
    };

    this.socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      this.handleWebSocketMessage(data);
    };

    this.socket.onclose = () => {
      console.log('WebSocket bağlantısı kapandı');
      this.attemptReconnect();
    };

    this.socket.onerror = (error) => {
      console.error('WebSocket hatası:', error);
    };
  }

  // Yeniden Bağlanma
  private attemptReconnect(): void {
    if (this.reconnectAttempts < this.maxReconnectAttempts) {
      this.reconnectAttempts++;
      setTimeout(() => {
        console.log(`Yeniden bağlanma denemesi ${this.reconnectAttempts}...`);
        this.initializeWebSocket();
      }, 3000 * this.reconnectAttempts);
    }
  }

  // WebSocket Mesaj İşleme
  private handleWebSocketMessage(data: any): void {
    switch (data.type) {
      case 'message':
        this.handleIncomingMessage(data.message);
        break;
      case 'message_status':
        this.updateMessageStatus(data.messageId, data.status);
        break;
      case 'typing':
        // Yazıyor bildirimi
        break;
      case 'read_receipt':
        this.handleReadReceipt(data.chatId, data.userId);
        break;
    }
  }

  // Mesh Dinleyici Kurulumu
  private setupMeshListener(): void {
    meshNetwork.onMessage((message) => {
      this.handleIncomingMessage(message);
    });
  }

  // Gelen Mesajı İşleme
  private async handleIncomingMessage(message: Message): Promise<void> {
    // Mesajı depola
    this.messages.set(message.id, message);

    // Sohbeti güncelle
    let chat = this.chats.get(this.getChatId(message.senderId, message.receiverId));
    if (chat) {
      chat.messages.push(message);
      chat.lastMessage = message;
      chat.updatedAt = new Date();
      if (message.receiverId === authService.getCurrentUser()?.id) {
        chat.unreadCount++;
      }
    }

    // Callback'leri çağır
    this.messageCallbacks.forEach(callback => callback(message));
    if (chat) {
      this.chatUpdateCallbacks.forEach(callback => callback(chat));
    }

    // Okundu bildirimi gönder
    if (message.receiverId === authService.getCurrentUser()?.id) {
      this.sendReadReceipt(message);
    }
  }

  // Mesaj Gönderme
  async sendMessage(
    receiverId: string,
    content: string,
    type: 'text' | 'image' | 'video' | 'audio' | 'file' = 'text',
    mediaUrl?: string,
    replyTo?: string
  ): Promise<ApiResponse<Message>> {
    try {
      const currentUser = authService.getCurrentUser();
      if (!currentUser) {
        return { success: false, error: 'Oturum açık değil' };
      }

      // Alıcının public key'ini al
      const receiverPublicKey = await this.getUserPublicKey(receiverId);
      if (!receiverPublicKey) {
        return { success: false, error: 'Alıcı bulunamadı' };
      }

      // Mesajı şifrele
      const encryptedContent = await encryptionService.encryptMessage(content, receiverPublicKey);

      // İmza oluştur
      const signature = await this.signMessage(content);

      const message: Message = {
        id: this.generateMessageId(),
        senderId: currentUser.id,
        receiverId,
        content,
        encryptedContent,
        timestamp: new Date(),
        status: 'sending',
        type,
        mediaUrl,
        replyTo,
        isForwarded: false,
        deliveryMethod: 'internet',
        ttl: 10,
        signature,
      };

      // Önce mesh ağı üzerinden göndermeyi dene
      const meshSuccess = await meshNetwork.sendMessage(message);
      
      if (meshSuccess) {
        message.status = 'sent';
        message.deliveryMethod = 'mesh';
        this.storeMessage(message);
        return { success: true, data: message };
      }

      // Mesh başarısız olursa WebSocket ile dene
      if (this.socket?.readyState === WebSocket.OPEN) {
        this.socket.send(JSON.stringify({
          type: 'send_message',
          message,
        }));
        message.status = 'sent';
        this.storeMessage(message);
        return { success: true, data: message };
      }

      // Her ikisi de başarısız olursa API'ye gönder
      const response = await fetch(`${API_BASE_URL}/messages`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authService.getToken()}`,
        },
        body: JSON.stringify(message),
      });

      if (response.ok) {
        message.status = 'sent';
        this.storeMessage(message);
        return { success: true, data: message };
      } else {
        message.status = 'failed';
        return { success: false, error: 'Mesaj gönderilemedi' };
      }
    } catch (error) {
      console.error('Mesaj gönderme hatası:', error);
      return { success: false, error: 'Mesaj gönderme hatası' };
    }
  }

  // Mesajı Depolama
  private storeMessage(message: Message): void {
    this.messages.set(message.id, message);
    
    const chatId = this.getChatId(message.senderId, message.receiverId);
    let chat = this.chats.get(chatId);
    
    if (!chat) {
      chat = {
        id: chatId,
        participants: [],
        messages: [],
        unreadCount: 0,
        isGroup: false,
        createdAt: new Date(),
        updatedAt: new Date(),
        isEncrypted: true,
      };
      this.chats.set(chatId, chat);
    }

    chat.messages.push(message);
    chat.lastMessage = message;
    chat.updatedAt = new Date();
  }

  // Sohbet ID'si Oluşturma
  private getChatId(userId1: string, userId2: string): string {
    return [userId1, userId2].sort().join('_');
  }

  // Mesaj ID'si Oluşturma
  private generateMessageId(): string {
    return `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  // Kullanıcı Public Key'i Alma
  private async getUserPublicKey(userId: string): Promise<CryptoKey | null> {
    try {
      const response = await fetch(`${API_BASE_URL}/users/${userId}/public-key`);
      if (response.ok) {
        const data = await response.json();
        return await encryptionService.importPublicKey(data.publicKey);
      }
      return null;
    } catch (error) {
      console.error('Public key alma hatası:', error);
      return null;
    }
  }

  // Mesaj İmzalama
  private async signMessage(content: string): Promise<string> {
    // Private key ile imzalama yapılacak
    return await encryptionService.hashData(content);
  }

  // Mesaj Durumunu Güncelleme
  private updateMessageStatus(messageId: string, status: Message['status']): void {
    const message = this.messages.get(messageId);
    if (message) {
      message.status = status;
      this.messageCallbacks.forEach(callback => callback(message));
    }
  }

  // Okundu Bildirimi Gönderme
  private sendReadReceipt(message: Message): void {
    if (this.socket?.readyState === WebSocket.OPEN) {
      this.socket.send(JSON.stringify({
        type: 'read_receipt',
        messageId: message.id,
        chatId: this.getChatId(message.senderId, message.receiverId),
      }));
    }
  }

  // Okundu Bildirimi İşleme
  private handleReadReceipt(chatId: string, _userId: string): void {
    const chat = this.chats.get(chatId);
    if (chat) {
      chat.messages.forEach(msg => {
        if (msg.senderId === authService.getCurrentUser()?.id && msg.status !== 'read') {
          msg.status = 'read';
        }
      });
      this.chatUpdateCallbacks.forEach(callback => callback(chat));
    }
  }

  // Sohbetleri Getirme
  async getChats(): Promise<ApiResponse<Chat[]>> {
    try {
      const response = await fetch(`${API_BASE_URL}/chats`, {
        headers: {
          'Authorization': `Bearer ${authService.getToken()}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        data.chats.forEach((chat: Chat) => {
          this.chats.set(chat.id, chat);
        });
        return { success: true, data: data.chats };
      } else {
        return { success: false, error: 'Sohbetler alınamadı' };
      }
    } catch (error) {
      return { success: false, error: 'Bağlantı hatası' };
    }
  }

  // Sohbet Mesajlarını Getirme
  async getChatMessages(chatId: string, limit = 50, offset = 0): Promise<ApiResponse<Message[]>> {
    try {
      const response = await fetch(
        `${API_BASE_URL}/chats/${chatId}/messages?limit=${limit}&offset=${offset}`,
        {
          headers: {
            'Authorization': `Bearer ${authService.getToken()}`,
          },
        }
      );

      if (response.ok) {
        const data = await response.json();
        return { success: true, data: data.messages };
      } else {
        return { success: false, error: 'Mesajlar alınamadı' };
      }
    } catch (error) {
      return { success: false, error: 'Bağlantı hatası' };
    }
  }

  // Mesaj Silme
  async deleteMessage(messageId: string, forEveryone = false): Promise<ApiResponse<void>> {
    try {
      const response = await fetch(`${API_BASE_URL}/messages/${messageId}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authService.getToken()}`,
        },
        body: JSON.stringify({ forEveryone }),
      });

      if (response.ok) {
        this.messages.delete(messageId);
        return { success: true, message: 'Mesaj silindi' };
      } else {
        return { success: false, error: 'Mesaj silinemedi' };
      }
    } catch (error) {
      return { success: false, error: 'Bağlantı hatası' };
    }
  }

  // Mesaj İletme
  async forwardMessage(messageId: string, receiverId: string): Promise<ApiResponse<Message>> {
    const originalMessage = this.messages.get(messageId);
    if (!originalMessage) {
      return { success: false, error: 'Mesaj bulunamadı' };
    }

    return this.sendMessage(
      receiverId,
      originalMessage.content,
      originalMessage.type,
      originalMessage.mediaUrl
    );
  }

  // Yazıyor Bildirimi
  sendTypingIndicator(chatId: string): void {
    if (this.socket?.readyState === WebSocket.OPEN) {
      this.socket.send(JSON.stringify({
        type: 'typing',
        chatId,
      }));
    }
  }

  // Mesaj Dinleyici Ekleme
  onMessage(callback: (message: Message) => void): () => void {
    this.messageCallbacks.push(callback);
    return () => {
      const index = this.messageCallbacks.indexOf(callback);
      if (index > -1) {
        this.messageCallbacks.splice(index, 1);
      }
    };
  }

  // Sohbet Güncelleme Dinleyici Ekleme
  onChatUpdate(callback: (chat: Chat) => void): () => void {
    this.chatUpdateCallbacks.push(callback);
    return () => {
      const index = this.chatUpdateCallbacks.indexOf(callback);
      if (index > -1) {
        this.chatUpdateCallbacks.splice(index, 1);
      }
    };
  }

  // Sohbet Arşivleme
  async archiveChat(chatId: string): Promise<ApiResponse<void>> {
    try {
      const response = await fetch(`${API_BASE_URL}/chats/${chatId}/archive`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${authService.getToken()}`,
        },
      });

      if (response.ok) {
        return { success: true, message: 'Sohbet arşivlendi' };
      } else {
        return { success: false, error: 'Arşivleme başarısız' };
      }
    } catch (error) {
      return { success: false, error: 'Bağlantı hatası' };
    }
  }

  // Sohbeti Sessize Alma
  async muteChat(chatId: string, duration: number): Promise<ApiResponse<void>> {
    try {
      const response = await fetch(`${API_BASE_URL}/chats/${chatId}/mute`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authService.getToken()}`,
        },
        body: JSON.stringify({ duration }),
      });

      if (response.ok) {
        return { success: true, message: 'Sohbet sessize alındı' };
      } else {
        return { success: false, error: 'İşlem başarısız' };
      }
    } catch (error) {
      return { success: false, error: 'Bağlantı hatası' };
    }
  }
}

export const messagingService = MessagingService.getInstance();
