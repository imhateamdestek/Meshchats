// Bot Servisi - Telegram BotFather benzeri bot yönetimi

import type { Bot, BotCommand, Message, ApiResponse } from '@/types';
import { authService } from './auth';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000/api';

export class BotService {
  private static instance: BotService;
  private bots: Map<string, Bot> = new Map();
  private runningBots: Map<string, Worker> = new Map();
  private messageHandlers: Map<string, ((message: Message) => void)[]> = new Map();

  private constructor() {}

  static getInstance(): BotService {
    if (!BotService.instance) {
      BotService.instance = new BotService();
    }
    return BotService.instance;
  }

  // Yeni Bot Oluşturma
  async createBot(
    name: string,
    username: string,
    description: string,
    language: 'python' | 'javascript' = 'python'
  ): Promise<ApiResponse<Bot>> {
    try {
      // Kullanıcı adı kontrolü
      const usernameCheck = await this.checkBotUsername(username);
      if (!usernameCheck.available) {
        return { success: false, error: 'Bot kullanıcı adı zaten kullanımda' };
      }

      const response = await fetch(`${API_BASE_URL}/bots`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authService.getToken()}`,
        },
        body: JSON.stringify({
          name,
          username,
          description,
          language,
          script: this.getDefaultBotScript(language),
        }),
      });

      const data = await response.json();

      if (response.ok) {
        this.bots.set(data.bot.id, data.bot);
        return { success: true, data: data.bot };
      } else {
        return { success: false, error: data.error || 'Bot oluşturma başarısız' };
      }
    } catch (error) {
      console.error('Bot oluşturma hatası:', error);
      return { success: false, error: 'Bağlantı hatası' };
    }
  }

  // Varsayılan Bot Script'i
  private getDefaultBotScript(language: 'python' | 'javascript'): string {
    if (language === 'python') {
      return `# MeshChat Bot - Python
# Bu bot MeshChat API'sini kullanır

import json
import requests

class MeshChatBot:
    def __init__(self, token):
        self.token = token
        self.base_url = "https://api.meshchat.com/v1"
        self.commands = {
            '/start': self.start_command,
            '/help': self.help_command,
            '/echo': self.echo_command,
        }
    
    def handle_message(self, message):
        '''Gelen mesajları işle'''
        text = message.get('content', '')
        chat_id = message.get('senderId')
        
        # Komut kontrolü
        if text.startswith('/'):
            command = text.split()[0]
            if command in self.commands:
                self.commands[command](chat_id, text)
            else:
                self.send_message(chat_id, "Bilinmeyen komut. /help yazarak komutları görebilirsiniz.")
        else:
            # Normal mesaj işleme
            self.process_message(chat_id, text)
    
    def start_command(self, chat_id, text):
        '''/start komutu'''
        welcome_message = """
🤖 Merhaba! Ben MeshChat Bot'uyum.

Kullanılabilir komutlar:
/start - Bot'u başlat
/help - Yardım menüsü
/echo <mesaj> - Mesajınızı tekrarlar

Özelleştirmek için kodumu düzenleyin!
        """
        self.send_message(chat_id, welcome_message)
    
    def help_command(self, chat_id, text):
        '''/help komutu'''
        help_text = """
📚 Bot Komutları:

/start - Bot'u başlatır
/help - Bu yardım mesajını gösterir
/echo <mesaj> - Yazdığınız mesajı tekrarlar

🛠️ Gelişmiş Özellikler:
- Otomatik yanıtlar
- Medya işleme
- Grup yönetimi
- Özel komutlar

Daha fazla bilgi için: docs.meshchat.com
        """
        self.send_message(chat_id, help_text)
    
    def echo_command(self, chat_id, text):
        '''/echo komutu'''
        echo_text = text.replace('/echo', '').strip()
        if echo_text:
            self.send_message(chat_id, f"📢 {echo_text}")
        else:
            self.send_message(chat_id, "Kullanım: /echo <mesaj>")
    
    def process_message(self, chat_id, text):
        '''Normal mesajları işle'''
        # Buraya kendi mantığınızı ekleyin
        response = f"Mesajınız alındı: {text}"
        self.send_message(chat_id, response)
    
    def send_message(self, chat_id, text):
        '''Mesaj gönder'''
        url = f"{self.base_url}/bots/send"
        headers = {"Authorization": f"Bearer {self.token}"}
        data = {
            "chat_id": chat_id,
            "text": text
        }
        response = requests.post(url, headers=headers, json=data)
        return response.json()

# Bot'u çalıştır
if __name__ == "__main__":
    bot = MeshChatBot("YOUR_BOT_TOKEN")
    # Webhook veya polling başlat
    print("Bot çalışıyor...")
`;
    } else {
      return `// MeshChat Bot - JavaScript
// Bu bot MeshChat API'sini kullanır

class MeshChatBot {
  constructor(token) {
    this.token = token;
    this.baseUrl = 'https://api.meshchat.com/v1';
    this.commands = {
      '/start': this.startCommand.bind(this),
      '/help': this.helpCommand.bind(this),
      '/echo': this.echoCommand.bind(this),
    };
  }

  // Gelen mesajları işle
  async handleMessage(message) {
    const text = message.content || '';
    const chatId = message.senderId;

    // Komut kontrolü
    if (text.startsWith('/')) {
      const command = text.split(' ')[0];
      if (this.commands[command]) {
        await this.commands[command](chatId, text);
      } else {
        await this.sendMessage(chatId, 'Bilinmeyen komut. /help yazarak komutları görebilirsiniz.');
      }
    } else {
      // Normal mesaj işleme
      await this.processMessage(chatId, text);
    }
  }

  // /start komutu
  async startCommand(chatId, text) {
    const welcomeMessage = \`
🤖 Merhaba! Ben MeshChat Bot'uyum.

Kullanılabilir komutlar:
/start - Bot'u başlat
/help - Yardım menüsü
/echo <mesaj> - Mesajınızı tekrarlar

Özelleştirmek için kodumu düzenleyin!
    \`;
    await this.sendMessage(chatId, welcomeMessage);
  }

  // /help komutu
  async helpCommand(chatId, text) {
    const helpText = \`
📚 Bot Komutları:

/start - Bot'u başlatır
/help - Bu yardım mesajını gösterir
/echo <mesaj> - Yazdığınız mesajı tekrarlar

🛠️ Gelişmiş Özellikler:
- Otomatik yanıtlar
- Medya işleme
- Grup yönetimi
- Özel komutlar

Daha fazla bilgi için: docs.meshchat.com
    \`;
    await this.sendMessage(chatId, helpText);
  }

  // /echo komutu
  async echoCommand(chatId, text) {
    const echoText = text.replace('/echo', '').trim();
    if (echoText) {
      await this.sendMessage(chatId, \`📢 \${echoText}\`);
    } else {
      await this.sendMessage(chatId, 'Kullanım: /echo <mesaj>');
    }
  }

  // Normal mesajları işle
  async processMessage(chatId, text) {
    // Buraya kendi mantığınızı ekleyin
    const response = \`Mesajınız alındı: \${text}\`;
    await this.sendMessage(chatId, response);
  }

  // Mesaj gönder
  async sendMessage(chatId, text) {
    const url = \`\${this.baseUrl}/bots/send\`;
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Authorization': \`Bearer \${this.token}\`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        chat_id: chatId,
        text: text,
      }),
    });
    return await response.json();
  }
}

// Bot'u çalıştır
const bot = new MeshChatBot('YOUR_BOT_TOKEN');
console.log('Bot çalışıyor...');

// Örnek: Webhook ile mesaj alma
// app.post('/webhook', (req, res) => {
//   bot.handleMessage(req.body);
//   res.sendStatus(200);
// });
`;
    }
  }

  // Bot Kullanıcı Adı Kontrolü
  async checkBotUsername(username: string): Promise<{ available: boolean }> {
    try {
      const response = await fetch(`${API_BASE_URL}/bots/check-username?username=${username}`);
      const data = await response.json();
      return { available: data.available };
    } catch (error) {
      return { available: false };
    }
  }

  // Bot Script'ini Güncelleme
  async updateBotScript(botId: string, script: string): Promise<ApiResponse<Bot>> {
    try {
      const response = await fetch(`${API_BASE_URL}/bots/${botId}/script`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authService.getToken()}`,
        },
        body: JSON.stringify({ script }),
      });

      const data = await response.json();

      if (response.ok) {
        this.bots.set(botId, data.bot);
        return { success: true, data: data.bot };
      } else {
        return { success: false, error: data.error };
      }
    } catch (error) {
      return { success: false, error: 'Bağlantı hatası' };
    }
  }

  // Bot Komutlarını Güncelleme
  async updateBotCommands(botId: string, commands: BotCommand[]): Promise<ApiResponse<Bot>> {
    try {
      const response = await fetch(`${API_BASE_URL}/bots/${botId}/commands`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authService.getToken()}`,
        },
        body: JSON.stringify({ commands }),
      });

      const data = await response.json();

      if (response.ok) {
        this.bots.set(botId, data.bot);
        return { success: true, data: data.bot };
      } else {
        return { success: false, error: data.error };
      }
    } catch (error) {
      return { success: false, error: 'Bağlantı hatası' };
    }
  }

  // Bot'u Başlatma
  async startBot(botId: string): Promise<ApiResponse<void>> {
    try {
      const bot = this.bots.get(botId);
      if (!bot) {
        return { success: false, error: 'Bot bulunamadı' };
      }

      // Web Worker ile bot'u çalıştır
      if (bot.language === 'javascript') {
        const worker = new Worker(
          URL.createObjectURL(new Blob([bot.script], { type: 'application/javascript' }))
        );
        
        worker.onmessage = (event) => {
          this.handleBotMessage(botId, event.data);
        };

        this.runningBots.set(botId, worker);
      }

      // API'ye bot'u başlatma bildirimi gönder
      const response = await fetch(`${API_BASE_URL}/bots/${botId}/start`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${authService.getToken()}`,
        },
      });

      if (response.ok) {
        bot.isActive = true;
        return { success: true, message: 'Bot başlatıldı' };
      } else {
        return { success: false, error: 'Bot başlatılamadı' };
      }
    } catch (error) {
      console.error('Bot başlatma hatası:', error);
      return { success: false, error: 'Bot başlatma hatası' };
    }
  }

  // Bot'u Durdurma
  async stopBot(botId: string): Promise<ApiResponse<void>> {
    try {
      const worker = this.runningBots.get(botId);
      if (worker) {
        worker.terminate();
        this.runningBots.delete(botId);
      }

      const response = await fetch(`${API_BASE_URL}/bots/${botId}/stop`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${authService.getToken()}`,
        },
      });

      if (response.ok) {
        const bot = this.bots.get(botId);
        if (bot) bot.isActive = false;
        return { success: true, message: 'Bot durduruldu' };
      } else {
        return { success: false, error: 'Bot durdurulamadı' };
      }
    } catch (error) {
      return { success: false, error: 'Bağlantı hatası' };
    }
  }

  // Bot Mesajını İşleme
  private handleBotMessage(botId: string, data: any): void {
    const handlers = this.messageHandlers.get(botId);
    if (handlers) {
      handlers.forEach(handler => handler(data));
    }
  }

  // Bot Mesaj Dinleyici Ekleme
  onBotMessage(botId: string, callback: (message: Message) => void): () => void {
    if (!this.messageHandlers.has(botId)) {
      this.messageHandlers.set(botId, []);
    }
    
    const handlers = this.messageHandlers.get(botId)!;
    handlers.push(callback);

    return () => {
      const index = handlers.indexOf(callback);
      if (index > -1) {
        handlers.splice(index, 1);
      }
    };
  }

  // Bot'ları Getirme
  async getBots(): Promise<ApiResponse<Bot[]>> {
    try {
      const response = await fetch(`${API_BASE_URL}/bots`, {
        headers: {
          'Authorization': `Bearer ${authService.getToken()}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        data.bots.forEach((bot: Bot) => {
          this.bots.set(bot.id, bot);
        });
        return { success: true, data: data.bots };
      } else {
        return { success: false, error: 'Botlar alınamadı' };
      }
    } catch (error) {
      return { success: false, error: 'Bağlantı hatası' };
    }
  }

  // Bot Silme
  async deleteBot(botId: string): Promise<ApiResponse<void>> {
    try {
      // Önce bot'u durdur
      await this.stopBot(botId);

      const response = await fetch(`${API_BASE_URL}/bots/${botId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${authService.getToken()}`,
        },
      });

      if (response.ok) {
        this.bots.delete(botId);
        return { success: true, message: 'Bot silindi' };
      } else {
        return { success: false, error: 'Bot silinemedi' };
      }
    } catch (error) {
      return { success: false, error: 'Bağlantı hatası' };
    }
  }

  // Bot Webhook Ayarlama
  async setWebhook(botId: string, webhookUrl: string): Promise<ApiResponse<void>> {
    try {
      const response = await fetch(`${API_BASE_URL}/bots/${botId}/webhook`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authService.getToken()}`,
        },
        body: JSON.stringify({ webhookUrl }),
      });

      if (response.ok) {
        const bot = this.bots.get(botId);
        if (bot) bot.webhookUrl = webhookUrl;
        return { success: true, message: 'Webhook ayarlandı' };
      } else {
        return { success: false, error: 'Webhook ayarlanamadı' };
      }
    } catch (error) {
      return { success: false, error: 'Bağlantı hatası' };
    }
  }

  // Bot İstatistikleri
  async getBotStats(botId: string): Promise<ApiResponse<any>> {
    try {
      const response = await fetch(`${API_BASE_URL}/bots/${botId}/stats`, {
        headers: {
          'Authorization': `Bearer ${authService.getToken()}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        return { success: true, data: data.stats };
      } else {
        return { success: false, error: 'İstatistikler alınamadı' };
      }
    } catch (error) {
      return { success: false, error: 'Bağlantı hatası' };
    }
  }
}

export const botService = BotService.getInstance();
