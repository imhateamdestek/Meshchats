import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import type { User, AuthState } from '@/types';
import { authService } from '@/services/auth';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  register: (email: string, password: string, username: string, displayName: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  updateProfile: (updates: Partial<User>) => Promise<{ success: boolean; error?: string }>;
  changePassword: (currentPassword: string, newPassword: string) => Promise<{ success: boolean; error?: string }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const initAuth = () => {
      const state = authService.getAuthState();
      setUser(state.user);
      setIsAuthenticated(state.isAuthenticated);
      setIsLoading(false);
    };

    initAuth();

    const unsubscribe = authService.onAuthChange((state: AuthState) => {
      setUser(state.user);
      setIsAuthenticated(state.isAuthenticated);
    });

    return unsubscribe;
  }, []);

  const login = useCallback(async (email: string, password: string) => {
    setIsLoading(true);
    const result = await authService.loginWithEmail(email, password);
    setIsLoading(false);
    
    if (result.success) {
      return { success: true };
    } else {
      return { success: false, error: result.error };
    }
  }, []);

  const register = useCallback(async (email: string, password: string, username: string, displayName: string) => {
    setIsLoading(true);
    const result = await authService.registerWithEmail(email, password, username, displayName);
    setIsLoading(false);
    
    if (result.success) {
      return { success: true };
    } else {
      return { success: false, error: result.error };
    }
  }, []);

  const logout = useCallback(() => {
    authService.logout();
  }, []);

  const updateProfile = useCallback(async (updates: Partial<User>) => {
    const result = await authService.updateProfile(updates);
    if (result.success) {
      return { success: true };
    } else {
      return { success: false, error: result.error };
    }
  }, []);

  const changePassword = useCallback(async (currentPassword: string, newPassword: string) => {
    const result = await authService.changePassword(currentPassword, newPassword);
    if (result.success) {
      return { success: true };
    } else {
      return { success: false, error: result.error };
    }
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated,
        isLoading,
        login,
        register,
        logout,
        updateProfile,
        changePassword,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
