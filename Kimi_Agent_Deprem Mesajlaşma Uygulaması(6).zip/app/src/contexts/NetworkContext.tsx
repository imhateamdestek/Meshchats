import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import type { NetworkStatus } from '@/types';
import { meshNetwork } from '@/services/meshNetwork';

interface NetworkContextType {
  status: NetworkStatus;
  isOnline: boolean;
  connectionType: string;
  isMeshActive: boolean;
  connectedNodes: number;
  pendingMessages: number;
  enableMesh: () => Promise<void>;
  disableMesh: () => void;
  connectBluetooth: () => Promise<boolean>;
}

const defaultStatus: NetworkStatus = {
  isOnline: navigator.onLine,
  connectionType: 'none',
  signalStrength: 0,
  isMeshActive: false,
  connectedNodes: 0,
  pendingMessages: 0,
};

const NetworkContext = createContext<NetworkContextType | undefined>(undefined);

export const NetworkProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [status, setStatus] = useState<NetworkStatus>(defaultStatus);

  useEffect(() => {
    meshNetwork.onStatusChange((newStatus: NetworkStatus) => {
      setStatus(newStatus);
    });

    meshNetwork.initialize();

    return () => {
      meshNetwork.stop();
    };
  }, []);

  const enableMesh = useCallback(async () => {
    await meshNetwork.initialize();
  }, []);

  const disableMesh = useCallback(() => {
    meshNetwork.stop();
  }, []);

  const connectBluetooth = useCallback(async () => {
    return await meshNetwork.connectBluetooth();
  }, []);

  return (
    <NetworkContext.Provider
      value={{
        status,
        isOnline: status.isOnline,
        connectionType: status.connectionType,
        isMeshActive: status.isMeshActive,
        connectedNodes: status.connectedNodes,
        pendingMessages: status.pendingMessages,
        enableMesh,
        disableMesh,
        connectBluetooth,
      }}
    >
      {children}
    </NetworkContext.Provider>
  );
};

export const useNetwork = () => {
  const context = useContext(NetworkContext);
  if (context === undefined) {
    throw new Error('useNetwork must be used within a NetworkProvider');
  }
  return context;
};
