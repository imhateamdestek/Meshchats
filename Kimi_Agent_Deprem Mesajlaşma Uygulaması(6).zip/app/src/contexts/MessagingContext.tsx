import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import type { Message, Chat } from '@/types';
import { messagingService } from '@/services/messaging';

interface MessagingContextType {
  chats: Chat[];
  activeChat: Chat | null;
  messages: Message[];
  unreadCount: number;
  setActiveChat: (chat: Chat | null) => void;
  sendMessage: (receiverId: string, content: string, type?: Message['type'], mediaUrl?: string) => Promise<void>;
  deleteMessage: (messageId: string, forEveryone?: boolean) => Promise<void>;
  forwardMessage: (messageId: string, receiverId: string) => Promise<void>;
  loadChats: () => Promise<void>;
  loadMessages: (chatId: string) => Promise<void>;
  sendTypingIndicator: (chatId: string) => void;
  archiveChat: (chatId: string) => Promise<void>;
  muteChat: (chatId: string, duration: number) => Promise<void>;
}

const MessagingContext = createContext<MessagingContextType | undefined>(undefined);

export const MessagingProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [chats, setChats] = useState<Chat[]>([]);
  const [activeChat, setActiveChat] = useState<Chat | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    const unsubscribeMessage = messagingService.onMessage((message: Message) => {
      setMessages(prev => [...prev, message]);
      
      setChats(prev => {
        const chatIndex = prev.findIndex(c => 
          c.participants.some(p => p.id === message.senderId)
        );
        
        if (chatIndex > -1) {
          const updatedChats = [...prev];
          updatedChats[chatIndex].lastMessage = message;
          updatedChats[chatIndex].updatedAt = new Date();
          if (activeChat?.id !== updatedChats[chatIndex].id) {
            updatedChats[chatIndex].unreadCount++;
          }
          return updatedChats.sort((a, b) => 
            new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
          );
        }
        return prev;
      });

      setUnreadCount(prev => prev + 1);
    });

    const unsubscribeChat = messagingService.onChatUpdate((updatedChat: Chat) => {
      setChats(prev => {
        const index = prev.findIndex(c => c.id === updatedChat.id);
        if (index > -1) {
          const updated = [...prev];
          updated[index] = updatedChat;
          return updated;
        }
        return [...prev, updatedChat];
      });
    });

    return () => {
      unsubscribeMessage();
      unsubscribeChat();
    };
  }, [activeChat]);

  const loadChats = useCallback(async () => {
    const result = await messagingService.getChats();
    if (result.success && result.data) {
      setChats(result.data.sort((a, b) => 
        new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
      ));
      setUnreadCount(result.data.reduce((acc, chat) => acc + chat.unreadCount, 0));
    }
  }, []);

  const loadMessages = useCallback(async (chatId: string) => {
    const result = await messagingService.getChatMessages(chatId);
    if (result.success && result.data) {
      setMessages(result.data);
    }
  }, []);

  const sendMessage = useCallback(async (
    receiverId: string,
    content: string,
    type: Message['type'] = 'text',
    mediaUrl?: string
  ) => {
    const result = await messagingService.sendMessage(receiverId, content, type, mediaUrl);
    if (!result.success) {
      throw new Error(result.error);
    }
  }, []);

  const deleteMessage = useCallback(async (messageId: string, forEveryone = false) => {
    const result = await messagingService.deleteMessage(messageId, forEveryone);
    if (!result.success) {
      throw new Error(result.error);
    }
    setMessages(prev => prev.filter(m => m.id !== messageId));
  }, []);

  const forwardMessage = useCallback(async (messageId: string, receiverId: string) => {
    const result = await messagingService.forwardMessage(messageId, receiverId);
    if (!result.success) {
      throw new Error(result.error);
    }
  }, []);

  const sendTypingIndicator = useCallback((chatId: string) => {
    messagingService.sendTypingIndicator(chatId);
  }, []);

  const archiveChat = useCallback(async (chatId: string) => {
    const result = await messagingService.archiveChat(chatId);
    if (!result.success) {
      throw new Error(result.error);
    }
    setChats(prev => prev.filter(c => c.id !== chatId));
  }, []);

  const muteChat = useCallback(async (chatId: string, duration: number) => {
    const result = await messagingService.muteChat(chatId, duration);
    if (!result.success) {
      throw new Error(result.error);
    }
  }, []);

  return (
    <MessagingContext.Provider
      value={{
        chats,
        activeChat,
        messages,
        unreadCount,
        setActiveChat,
        sendMessage,
        deleteMessage,
        forwardMessage,
        loadChats,
        loadMessages,
        sendTypingIndicator,
        archiveChat,
        muteChat,
      }}
    >
      {children}
    </MessagingContext.Provider>
  );
};

export const useMessaging = () => {
  const context = useContext(MessagingContext);
  if (context === undefined) {
    throw new Error('useMessaging must be used within a MessagingProvider');
  }
  return context;
};
