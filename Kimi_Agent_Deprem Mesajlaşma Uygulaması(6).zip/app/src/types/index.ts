// MeshChat - Tip Tanımlamaları

export interface User {
  id: string;
  email: string;
  username: string;
  displayName: string;
  avatar?: string;
  status: 'online' | 'offline' | 'away' | 'busy';
  lastSeen: Date;
  createdAt: Date;
  isVerified: boolean;
  publicKey: string;
  wallPosts: WallPost[];
}

export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  content: string;
  encryptedContent?: string;
  timestamp: Date;
  status: 'sending' | 'sent' | 'delivered' | 'read' | 'failed';
  type: 'text' | 'image' | 'video' | 'audio' | 'file';
  mediaUrl?: string;
  replyTo?: string;
  isForwarded: boolean;
  deliveryMethod: 'internet' | 'wifi' | 'bluetooth' | 'mesh';
  ttl: number; // Time to live for mesh routing
  signature: string; // Digital signature for verification
}

export interface Chat {
  id: string;
  participants: User[];
  messages: Message[];
  unreadCount: number;
  lastMessage?: Message;
  isGroup: boolean;
  groupName?: string;
  groupAvatar?: string;
  createdAt: Date;
  updatedAt: Date;
  isEncrypted: boolean;
}

export interface WallPost {
  id: string;
  userId: string;
  content: string;
  mediaUrls: string[];
  mediaType: 'image' | 'video' | 'none';
  taggedUsers: string[];
  likes: number;
  comments: Comment[];
  createdAt: Date;
  updatedAt: Date;
}

export interface Comment {
  id: string;
  postId: string;
  userId: string;
  content: string;
  createdAt: Date;
}

export interface Bot {
  id: string;
  name: string;
  username: string;
  description: string;
  avatar?: string;
  ownerId: string;
  script: string;
  language: 'python' | 'javascript';
  isActive: boolean;
  webhookUrl?: string;
  commands: BotCommand[];
  createdAt: Date;
  updatedAt: Date;
}

export interface BotCommand {
  command: string;
  description: string;
  parameters?: string[];
}

export interface MeshNode {
  id: string;
  userId: string;
  deviceId: string;
  connectionType: 'wifi' | 'bluetooth' | 'hybrid';
  signalStrength: number;
  lastPing: Date;
  isRelay: boolean;
  hops: number;
  batteryLevel?: number;
}

export interface NetworkStatus {
  isOnline: boolean;
  connectionType: 'none' | 'cellular' | 'wifi' | 'bluetooth';
  signalStrength: number;
  isMeshActive: boolean;
  connectedNodes: number;
  pendingMessages: number;
}

export interface EncryptionKeys {
  publicKey: string;
  privateKey: string;
  symmetricKey?: string;
}

export interface DeliveryAttempt {
  messageId: string;
  method: 'internet' | 'wifi' | 'bluetooth';
  timestamp: Date;
  success: boolean;
  error?: string;
  nextAttempt?: Date;
}

export interface AppSettings {
  theme: 'light' | 'dark' | 'system';
  language: string;
  notifications: boolean;
  soundEnabled: boolean;
  vibrationEnabled: boolean;
  autoDownloadMedia: boolean;
  maxFileSize: number;
  meshEnabled: boolean;
  bluetoothEnabled: boolean;
  encryptionEnabled: boolean;
}

export interface AuthState {
  isAuthenticated: boolean;
  user: User | null;
  token: string | null;
  refreshToken: string | null;
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}
