import React from 'react';
import { useNetwork } from '@/contexts/NetworkContext';
import { Wifi, Bluetooth, Globe, AlertCircle } from 'lucide-react';

export const NetworkStatusIndicator: React.FC = () => {
  const { status, isOnline, isMeshActive, connectedNodes } = useNetwork();

  const getStatusIcon = () => {
    if (!isOnline && !isMeshActive) {
      return <AlertCircle className="w-5 h-5 text-red-500" />;
    }
    if (status.connectionType === 'wifi' || status.connectionType === 'cellular') {
      return <Globe className="w-5 h-5 text-green-500" />;
    }
    if (status.connectionType === 'bluetooth') {
      return <Bluetooth className="w-5 h-5 text-blue-500" />;
    }
    if (isMeshActive) {
      return <Wifi className="w-5 h-5 text-yellow-500" />;
    }
    return <AlertCircle className="w-5 h-5 text-gray-500" />;
  };

  const getStatusText = () => {
    if (!isOnline && !isMeshActive) {
      return 'Çevrimdışı';
    }
    if (status.connectionType === 'cellular') {
      return 'Mobil Veri';
    }
    if (status.connectionType === 'wifi') {
      return 'WiFi';
    }
    if (status.connectionType === 'bluetooth') {
      return 'Bluetooth';
    }
    if (isMeshActive) {
      return `Mesh Ağı (${connectedNodes} düğüm)`;
    }
    return 'Bilinmiyor';
  };

  return (
    <div className="flex items-center gap-2 px-3 py-1.5 bg-gray-100 dark:bg-gray-800 rounded-full">
      {getStatusIcon()}
      <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
        {getStatusText()}
      </span>
      {status.pendingMessages > 0 && (
        <span className="text-xs bg-yellow-500 text-white px-1.5 py-0.5 rounded-full">
          {status.pendingMessages}
        </span>
      )}
    </div>
  );
};
