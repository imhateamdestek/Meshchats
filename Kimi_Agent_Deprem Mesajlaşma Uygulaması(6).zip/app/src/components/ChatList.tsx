import React, { useEffect } from 'react';
import { useMessaging } from '@/contexts/MessagingContext';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { formatDistanceToNow } from '@/utils/date';

export const ChatList: React.FC = () => {
  const { chats, activeChat, setActiveChat, loadChats } = useMessaging();

  useEffect(() => {
    loadChats();
  }, [loadChats]);

  return (
    <div className="w-full h-full overflow-y-auto bg-white dark:bg-gray-900">
      <div className="p-4 border-b dark:border-gray-800">
        <h2 className="text-lg font-semibold">Sohbetler</h2>
      </div>
      <div className="divide-y dark:divide-gray-800">
        {chats.map((chat) => {
          const otherParticipant = chat.participants.find(
            p => p.id !== 'current-user-id'
          ) || chat.participants[0];

          return (
            <button
              key={chat.id}
              onClick={() => setActiveChat(chat)}
              className={`w-full p-4 flex items-center gap-3 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors ${
                activeChat?.id === chat.id ? 'bg-gray-100 dark:bg-gray-800' : ''
              }`}
            >
              <Avatar className="w-12 h-12">
                <AvatarImage src={otherParticipant?.avatar} />
                <AvatarFallback>
                  {otherParticipant?.displayName?.charAt(0) || '?'}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1 text-left">
                <div className="flex items-center justify-between">
                  <h3 className="font-medium text-gray-900 dark:text-gray-100">
                    {chat.isGroup ? chat.groupName : otherParticipant?.displayName}
                  </h3>
                  {chat.lastMessage && (
                    <span className="text-xs text-gray-500">
                      {formatDistanceToNow(new Date(chat.lastMessage.timestamp))}
                    </span>
                  )}
                </div>
                
                <div className="flex items-center justify-between mt-1">
                  <p className="text-sm text-gray-500 truncate max-w-[200px]">
                    {chat.lastMessage?.content || 'Henüz mesaj yok'}
                  </p>
                  {chat.unreadCount > 0 && (
                    <Badge variant="default" className="ml-2">
                      {chat.unreadCount}
                    </Badge>
                  )}
                </div>
              </div>
            </button>
          );
        })}
        
        {chats.length === 0 && (
          <div className="p-8 text-center text-gray-500">
            <p>Henüz sohbet yok</p>
            <p className="text-sm mt-1">Yeni bir sohbet başlatın</p>
          </div>
        )}
      </div>
    </div>
  );
};
