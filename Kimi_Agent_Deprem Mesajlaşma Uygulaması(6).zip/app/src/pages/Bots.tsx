import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import type { Bot } from '@/types';
import { botService } from '@/services/bot';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ArrowLeft, Plus, Play, Square, Trash2, Code, Settings, Bot as BotIcon } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export const Bots: React.FC = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [bots, setBots] = useState<Bot[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [newBot, setNewBot] = useState({
    name: '',
    username: '',
    description: '',
    language: 'python' as 'python' | 'javascript',
  });

  useEffect(() => {
    loadBots();
  }, []);

  const loadBots = async () => {
    const result = await botService.getBots();
    if (result.success && result.data) {
      setBots(result.data);
    }
  };

  const handleCreateBot = async () => {
    const result = await botService.createBot(
      newBot.name,
      newBot.username,
      newBot.description,
      newBot.language
    );

    if (result.success && result.data) {
      setBots([...bots, result.data]);
      setIsCreating(false);
      setNewBot({ name: '', username: '', description: '', language: 'python' });
      toast({
        title: 'Bot oluşturuldu',
        description: `${result.data.name} başarıyla oluşturuldu.`,
      });
    } else {
      toast({
        title: 'Hata',
        description: result.error || 'Bot oluşturulamadı',
        variant: 'destructive',
      });
    }
  };

  const handleStartBot = async (botId: string) => {
    const result = await botService.startBot(botId);
    if (result.success) {
      setBots(bots.map(bot => 
        bot.id === botId ? { ...bot, isActive: true } : bot
      ));
      toast({
        title: 'Bot başlatıldı',
        description: 'Bot çalışmaya başladı.',
      });
    }
  };

  const handleStopBot = async (botId: string) => {
    const result = await botService.stopBot(botId);
    if (result.success) {
      setBots(bots.map(bot => 
        bot.id === botId ? { ...bot, isActive: false } : bot
      ));
      toast({
        title: 'Bot durduruldu',
        description: 'Bot durduruldu.',
      });
    }
  };

  const handleDeleteBot = async (botId: string) => {
    const result = await botService.deleteBot(botId);
    if (result.success) {
      setBots(bots.filter(bot => bot.id !== botId));
      toast({
        title: 'Bot silindi',
        description: 'Bot başarıyla silindi.',
      });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 border-b dark:border-gray-700 px-4 py-3 sticky top-0 z-10">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('/chat')}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-xl font-bold">Bot Yöneticisi</h1>
          </div>
          <Dialog open={isCreating} onOpenChange={setIsCreating}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Yeni Bot
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>Yeni Bot Oluştur</DialogTitle>
                <DialogDescription>
                  Telegram BotFather tarzında bot oluşturun
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="botName">Bot Adı</Label>
                  <Input
                    id="botName"
                    placeholder="Örn: Hava Durumu Botu"
                    value={newBot.name}
                    onChange={(e) => setNewBot({ ...newBot, name: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="botUsername">Kullanıcı Adı</Label>
                  <Input
                    id="botUsername"
                    placeholder="Örn: havadurumu_bot"
                    value={newBot.username}
                    onChange={(e) => setNewBot({ ...newBot, username: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="botDescription">Açıklama</Label>
                  <Input
                    id="botDescription"
                    placeholder="Botun ne yaptığı..."
                    value={newBot.description}
                    onChange={(e) => setNewBot({ ...newBot, description: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Programlama Dili</Label>
                  <Tabs 
                    value={newBot.language} 
                    onValueChange={(v) => setNewBot({ ...newBot, language: v as 'python' | 'javascript' })}
                  >
                    <TabsList className="w-full">
                      <TabsTrigger value="python" className="flex-1">Python</TabsTrigger>
                      <TabsTrigger value="javascript" className="flex-1">JavaScript</TabsTrigger>
                    </TabsList>
                  </Tabs>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsCreating(false)}>
                  İptal
                </Button>
                <Button onClick={handleCreateBot}>
                  Oluştur
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </header>

      <div className="max-w-6xl mx-auto p-4">
        {/* Info Card */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center">
                <BotIcon className="w-6 h-6 text-blue-600 dark:text-blue-400" />
              </div>
              <div>
                <h2 className="text-lg font-semibold">BotFather Benzeri Bot Yönetimi</h2>
                <p className="text-gray-500 mt-1">
                  Kendi botlarınızı Python veya JavaScript ile oluşturun ve yönetin. 
                  Botlarınızı uygulama içinden özelleştirebilir veya kod yazarak geliştirebilirsiniz.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Bots Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {bots.map((bot) => (
            <Card key={bot.id}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      bot.isActive 
                        ? 'bg-green-100 dark:bg-green-900' 
                        : 'bg-gray-100 dark:bg-gray-800'
                    }`}>
                      <BotIcon className={`w-5 h-5 ${
                        bot.isActive 
                          ? 'text-green-600 dark:text-green-400' 
                          : 'text-gray-500'
                      }`} />
                    </div>
                    <div>
                      <CardTitle className="text-base">{bot.name}</CardTitle>
                      <CardDescription>@{bot.username}</CardDescription>
                    </div>
                  </div>
                  <div className={`w-2 h-2 rounded-full ${
                    bot.isActive ? 'bg-green-500' : 'bg-gray-400'
                  }`} />
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-500 mb-4">{bot.description}</p>
                <div className="flex items-center gap-2 mb-4">
                  <span className="text-xs bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">
                    {bot.language === 'python' ? '🐍 Python' : '⚡ JavaScript'}
                  </span>
                  <span className="text-xs text-gray-500">
                    {bot.commands.length} komut
                  </span>
                </div>
                <div className="flex gap-2">
                  {bot.isActive ? (
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex-1"
                      onClick={() => handleStopBot(bot.id)}
                    >
                      <Square className="w-4 h-4 mr-2" />
                      Durdur
                    </Button>
                  ) : (
                    <Button 
                      size="sm" 
                      className="flex-1"
                      onClick={() => handleStartBot(bot.id)}
                    >
                      <Play className="w-4 h-4 mr-2" />
                      Başlat
                    </Button>
                  )}
                  <Button 
                    variant="outline" 
                    size="icon"
                    onClick={() => navigate(`/bots/${bot.id}/edit`)}
                  >
                    <Code className="w-4 h-4" />
                  </Button>
                  <Button 
                    variant="outline" 
                    size="icon"
                    onClick={() => navigate(`/bots/${bot.id}/settings`)}
                  >
                    <Settings className="w-4 h-4" />
                  </Button>
                  <Button 
                    variant="outline" 
                    size="icon"
                    onClick={() => handleDeleteBot(bot.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {bots.length === 0 && (
          <Card>
            <CardContent className="py-12 text-center">
              <BotIcon className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
                Henüz bot yok
              </h3>
              <p className="text-gray-500 mb-4">
                İlk botunuzu oluşturmak için "Yeni Bot" butonuna tıklayın
              </p>
              <Button onClick={() => setIsCreating(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Bot Oluştur
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};
