import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { 
  Wifi, 
  Bluetooth, 
  Shield, 
  Zap, 
  Globe, 
  Lock,
  MessageCircle,
  Code,
  Users,
  Radio,
  Smartphone,
  Server
} from 'lucide-react';

export const Landing: React.FC = () => {
  const navigate = useNavigate();

  const features = [
    {
      icon: <Radio className="w-8 h-8 text-blue-500" />,
      title: 'Mesh Ağı Teknolojisi',
      description: 'İnternet olmadan bile telefondan telefona iletişim kurun. Deprem ve afet anlarında bile bağlantınızı koruyun.',
    },
    {
      icon: <Shield className="w-8 h-8 text-green-500" />,
      title: 'Uçtan Uca Şifreleme',
      description: 'Tüm mesajlarınız askeri düzeyde şifreleme ile korunur. Sadece siz ve alıcı okuyabilir.',
    },
    {
      icon: <Wifi className="w-8 h-8 text-purple-500" />,
      title: 'Çoklu Bağlantı',
      description: 'Mobil veri, WiFi ve Bluetooth ile kesintisiz iletişim. Bir bağlantı kesilirse diğeri devreye girer.',
    },
    {
      icon: <Code className="w-8 h-8 text-orange-500" />,
      title: 'Bot Geliştirme',
      description: 'Python veya JavaScript ile kendi botlarınızı oluşturun. Telegram BotFather tarzında bot yönetimi.',
    },
    {
      icon: <Users className="w-8 h-8 text-pink-500" />,
      title: 'Sosyal Duvar',
      description: 'Profil duvarınızda paylaşımlar yapın, fotoğraf ve videolar paylaşın, arkadaşlarınızı etiketleyin.',
    },
    {
      icon: <Lock className="w-8 h-8 text-red-500" />,
      title: 'Açık Kaynak',
      description: 'Tamamen açık kaynak kodlu. Güvenliğinizi kendiniz kontrol edin, istediğinizi değiştirin.',
    },
  ];

  const techStack = [
    { icon: <Globe className="w-6 h-6" />, name: 'WebRTC', desc: 'Eşler arası iletişim' },
    { icon: <Bluetooth className="w-6 h-6" />, name: 'Web Bluetooth', desc: 'Bluetooth bağlantısı' },
    { icon: <Zap className="w-6 h-6" />, name: 'WebCrypto API', desc: 'Güvenli şifreleme' },
    { icon: <Server className="w-6 h-6" />, name: 'Service Workers', desc: 'Çevrimdışı çalışma' },
    { icon: <Smartphone className="w-6 h-6" />, name: 'PWA', desc: 'Mobil uygulama deneyimi' },
    { icon: <MessageCircle className="w-6 h-6" />, name: 'WebSocket', desc: 'Gerçek zamanlı mesajlaşma' },
  ];

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 opacity-10" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-16 relative">
          <div className="text-center">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-blue-500 rounded-2xl mb-8">
              <MessageCircle className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-5xl md:text-7xl font-bold text-gray-900 dark:text-white mb-6">
              MeshChat
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 dark:text-gray-300 mb-4 max-w-3xl mx-auto">
              Deprem anında bile çalışan, telefondan telefona iletişim kuran
              <span className="text-blue-600 dark:text-blue-400 font-semibold"> süper güvenli</span> mesajlaşma uygulaması
            </p>
            <p className="text-lg text-gray-500 dark:text-gray-400 mb-8">
              İnternet yoksa WiFi, WiFi yoksa Bluetooth, hiçbiri yoksa Mesh Ağı!
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                className="text-lg px-8"
                onClick={() => navigate('/register')}
              >
                Ücretsiz Başla
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="text-lg px-8"
                onClick={() => navigate('/login')}
              >
                Giriş Yap
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50 dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
              Neden MeshChat?
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              Geleneksel mesajlaşma uygulamalarından farklı olarak, MeshChat her koşulda çalışır
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardContent className="pt-6">
                  <div className="mb-4">{feature.icon}</div>
                  <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                  <p className="text-gray-600 dark:text-gray-400">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
              Nasıl Çalışır?
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-400">
              Akıllı bağlantı yönetimi ile her zaman bağlı kalın
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { step: '1', title: 'Mobil Veri', desc: 'Önce internet üzerinden gönderir' },
              { step: '2', title: 'WiFi Direct', desc: 'İnternet yoksa WiFi ile aktarır' },
              { step: '3', title: 'Bluetooth', desc: 'WiFi yoksa Bluetooth dener' },
              { step: '4', title: 'Mesh Ağı', desc: 'Diğer telefonlar üzerinden iletir' },
            ].map((item, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-white">{item.step}</span>
                </div>
                <h3 className="text-lg font-semibold mb-2">{item.title}</h3>
                <p className="text-gray-600 dark:text-gray-400">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Tech Stack */}
      <section className="py-20 bg-gray-50 dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
              Teknolojiler
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-400">
              En son web teknolojileri ile geliştirildi
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {techStack.map((tech, index) => (
              <Card key={index} className="text-center">
                <CardContent className="pt-6">
                  <div className="flex justify-center mb-3">{tech.icon}</div>
                  <h4 className="font-semibold">{tech.name}</h4>
                  <p className="text-sm text-gray-500">{tech.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-6">
            Hemen Başlayın
          </h2>
          <p className="text-lg text-gray-600 dark:text-gray-400 mb-8">
            MeshChat'i kullanmaya başlayın ve her koşulda bağlı kalın.
            Ücretsiz, açık kaynak ve güvenli.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="text-lg px-8"
              onClick={() => navigate('/register')}
            >
              Hesap Oluştur
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="text-lg px-8"
              onClick={() => window.open('https://github.com/meshchat', '_blank')}
            >
              <Code className="w-5 h-5 mr-2" />
              GitHub'da Görüntüle
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <MessageCircle className="w-6 h-6" />
                <span className="text-xl font-bold">MeshChat</span>
              </div>
              <p className="text-gray-400">
                Her koşulda çalışan güvenli mesajlaşma
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Ürün</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">Özellikler</a></li>
                <li><a href="#" className="hover:text-white">Güvenlik</a></li>
                <li><a href="#" className="hover:text-white">Botlar</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Geliştiriciler</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">API</a></li>
                <li><a href="#" className="hover:text-white">Dokümantasyon</a></li>
                <li><a href="#" className="hover:text-white">GitHub</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">İletişim</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">Destek</a></li>
                <li><a href="#" className="hover:text-white">Gizlilik</a></li>
                <li><a href="#" className="hover:text-white">Kullanım Şartları</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 MeshChat. Açık kaynak projesi.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};
