import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { wallService } from '@/services/wall';
import type { WallPost } from '@/types';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { ArrowLeft, Image, Video, MapPin, Calendar, Heart, MessageCircle as MessageIcon, Share } from 'lucide-react';
import { formatDate } from '@/utils/date';

export const Profile: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [posts, setPosts] = useState<WallPost[]>([]);
  const [newPost, setNewPost] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (user) {
      loadPosts();
    }
  }, [user]);

  const loadPosts = async () => {
    if (!user) return;
    const result = await wallService.getUserWall(user.id);
    if (result.success && result.data) {
      setPosts(result.data);
    }
  };

  const handleCreatePost = async () => {
    if (!newPost.trim()) return;
    
    setIsLoading(true);
    const result = await wallService.createPost(newPost);
    if (result.success && result.data) {
      setPosts([result.data, ...posts]);
      setNewPost('');
    }
    setIsLoading(false);
  };

  const handleLike = async (postId: string) => {
    const result = await wallService.likePost(postId);
    if (result.success) {
      setPosts(posts.map(post => 
        post.id === postId 
          ? { ...post, likes: post.likes + 1 }
          : post
      ));
    }
  };

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 border-b dark:border-gray-700 px-4 py-3 sticky top-0 z-10">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate('/chat')}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-xl font-bold">Profil</h1>
        </div>
      </header>

      <div className="max-w-4xl mx-auto p-4">
        {/* Profile Header */}
        <Card className="mb-6">
          <div className="h-48 bg-gradient-to-r from-blue-500 to-purple-600 rounded-t-lg" />
          <CardContent className="relative pt-0">
            <div className="flex flex-col md:flex-row items-start md:items-end -mt-16 mb-4 gap-4">
              <Avatar className="w-32 h-32 border-4 border-white dark:border-gray-800">
                <AvatarImage src={user.avatar} />
                <AvatarFallback className="text-4xl">{user.displayName.charAt(0)}</AvatarFallback>
              </Avatar>
              <div className="flex-1 mb-2">
                <h2 className="text-2xl font-bold">{user.displayName}</h2>
                <p className="text-gray-500">@{user.username}</p>
              </div>
              <Button onClick={() => navigate('/settings')}>
                Profili Düzenle
              </Button>
            </div>

            <div className="flex flex-wrap gap-4 text-sm text-gray-500">
              <div className="flex items-center gap-1">
                <MapPin className="w-4 h-4" />
                <span>Konum bilgisi</span>
              </div>
              <div className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                <span>Katılım: {formatDate(new Date(user.createdAt))}</span>
              </div>
            </div>

            <div className="flex gap-6 mt-4">
              <div>
                <span className="font-bold">{posts.length}</span>
                <span className="text-gray-500 ml-1">Gönderi</span>
              </div>
              <div>
                <span className="font-bold">0</span>
                <span className="text-gray-500 ml-1">Takipçi</span>
              </div>
              <div>
                <span className="font-bold">0</span>
                <span className="text-gray-500 ml-1">Takip</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="posts" className="w-full">
          <TabsList className="w-full">
            <TabsTrigger value="posts" className="flex-1">Gönderiler</TabsTrigger>
            <TabsTrigger value="media" className="flex-1">Medya</TabsTrigger>
            <TabsTrigger value="likes" className="flex-1">Beğeniler</TabsTrigger>
          </TabsList>

          <TabsContent value="posts" className="space-y-4">
            {/* New Post */}
            <Card>
              <CardContent className="pt-4">
                <Textarea
                  placeholder="Ne düşünüyorsun?"
                  value={newPost}
                  onChange={(e) => setNewPost(e.target.value)}
                  className="mb-4"
                />
                <div className="flex justify-between items-center">
                  <div className="flex gap-2">
                    <Button variant="ghost" size="icon">
                      <Image className="w-5 h-5" />
                    </Button>
                    <Button variant="ghost" size="icon">
                      <Video className="w-5 h-5" />
                    </Button>
                  </div>
                  <Button 
                    onClick={handleCreatePost} 
                    disabled={!newPost.trim() || isLoading}
                  >
                    Paylaş
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Posts */}
            {posts.map((post) => (
              <Card key={post.id}>
                <CardHeader className="pb-2">
                  <div className="flex items-center gap-3">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src={user.avatar} />
                      <AvatarFallback>{user.displayName.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{user.displayName}</p>
                      <p className="text-sm text-gray-500">
                        {formatDate(new Date(post.createdAt))}
                      </p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="mb-4">{post.content}</p>
                  {post.mediaUrls.length > 0 && (
                    <div className="grid grid-cols-2 gap-2 mb-4">
                      {post.mediaUrls.map((url, index) => (
                        <img
                          key={index}
                          src={url}
                          alt={`Media ${index}`}
                          className="rounded-lg w-full h-48 object-cover"
                        />
                      ))}
                    </div>
                  )}
                  <div className="flex items-center gap-6 text-gray-500">
                    <button 
                      className="flex items-center gap-2 hover:text-red-500"
                      onClick={() => handleLike(post.id)}
                    >
                      <Heart className="w-5 h-5" />
                      <span>{post.likes}</span>
                    </button>
                    <button className="flex items-center gap-2 hover:text-blue-500">
                      <MessageIcon className="w-5 h-5" />
                      <span>{post.comments.length}</span>
                    </button>
                    <button className="flex items-center gap-2 hover:text-green-500">
                      <Share className="w-5 h-5" />
                    </button>
                  </div>
                </CardContent>
              </Card>
            ))}

            {posts.length === 0 && (
              <Card>
                <CardContent className="py-8 text-center text-gray-500">
                  <p>Henüz gönderi yok</p>
                  <p className="text-sm">İlk gönderini paylaş!</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="media">
            <Card>
              <CardContent className="py-8 text-center text-gray-500">
                <p>Medya içeriği burada görünecek</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="likes">
            <Card>
              <CardContent className="py-8 text-center text-gray-500">
                <p>Beğenilen gönderiler burada görünecek</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};
