# MeshChat - Deprem Anında İletişim 🚨📱

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![React](https://img.shields.io/badge/React-18.2.0-blue.svg)](https://reactjs.org/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.0.0-blue.svg)](https://www.typescriptlang.org/)
[![PWA](https://img.shields.io/badge/PWA-Ready-green.svg)](https://web.dev/progressive-web-apps/)

> **İnternet olmadan bile çalışan, telefondan telefona iletişim kuran süper güvenli mesajlaşma uygulaması!**

MeshChat, deprem ve afet anlarında operatörler çöktüğünde bile çalışan, mesh ağı teknolojisi kullanan bir mesajlaşma platformudur. İnternet yoksa WiFi, WiFi yoksa Bluetooth, hiçbiri yoksa komşunun telefonu üzerinden mesajınızı iletir!

## 🌟 Özellikler

### 🌐 Çoklu Bağlantı Sistemi
- **Mobil Veri** → Öncelikli bağlantı
- **WiFi Direct** → İnternet olmadan telefondan telefona
- **Bluetooth** → Kısa mesafe iletişimi
- **Mesh Ağı** → Çok atlamalı iletişim

### 🔐 Güvenlik
- **Uçtan Uca Şifreleme** (RSA-4096 + AES-256-GCM)
- **Dijital İmzalar** ile mesaj doğrulama
- **Açık Kaynak** - Güvenliğinizi kendiniz kontrol edin
- **Self-hosted** seçeneği

### 🤖 Bot Sistemi (BotFather Tarzı)
- **Python** ve **JavaScript** ile bot geliştirme
- **Webhook** ve **Polling** desteği
- **Özel komutlar** tanımlama
- **Bot istatistikleri**

### 📱 Sosyal Özellikler
- **Profil Duvarı** - Paylaşım, fotoğraf, video
- **Etiketleme** sistem
- **Beğenme** ve **yorum** yapma
- **Hikayeler** (yakında)

### 💻 Teknik Özellikler
- **Progressive Web App (PWA)**
- **Çevrimdışı çalışma**
- **Arka plan senkronizasyonu**
- **Push bildirimleri**
- **WebRTC** ile eşler arası iletişim
- **Web Bluetooth API** desteği

## 📋 İçindekiler

1. [Hızlı Başlangıç](#hızlı-başlangıç)
2. [Proje Yapısı](#proje-yapısı)
3. [Kurulum](#kurulum)
4. [Geliştirme](#geliştirme)
5. [Build ve Dağıtım](#build-ve-dağıtım)
6. [Google Play Yayınlama](#google-play-yayınlama)
7. [API Dokümantasyonu](#api-dokümantasyonu)
8. [Bot Geliştirme](#bot-geliştirme)
9. [Mobil Uygulama Yapma](#mobil-uygulama-yapma)
10. [Sık Sorulan Sorular](#sık-sorulan-sorular)

## 🚀 Hızlı Başlangıç

### Gereksinimler
- Node.js 18+ 
- npm veya yarn
- Modern bir web tarayıcısı
- (Opsiyonel) Android Studio (mobil uygulama için)

### 1. Projeyi İndirme

```bash
# Git ile klonlayın
git clone https://github.com/kullaniciadi/meshchat.git
cd meshchat

# VEYA zip dosyasını indirin ve çıkarın
unzip meshchat.zip
cd meshchat
```

### 2. Bağımlılıkları Yükleme

```bash
npm install
```

### 3. Geliştirme Sunucusunu Başlatma

```bash
npm run dev
```

Uygulama `http://localhost:5173` adresinde çalışacaktır.

### 4. Build Alma

```bash
npm run build
```

Build çıktısı `dist/` klasöründe oluşur.

## 📁 Proje Yapısı

```
meshchat/
├── public/                 # Statik dosyalar
│   ├── manifest.json       # PWA manifest
│   ├── sw.js              # Service Worker
│   └── icons/             # Uygulama ikonları
├── src/
│   ├── components/        # React bileşenleri
│   │   ├── ChatList.tsx
│   │   ├── ChatWindow.tsx
│   │   └── NetworkStatus.tsx
│   ├── contexts/          # React Context'ler
│   │   ├── AuthContext.tsx
│   │   ├── NetworkContext.tsx
│   │   └── MessagingContext.tsx
│   ├── hooks/             # Custom React hooks
│   │   ├── useLocalStorage.ts
│   │   └── useDebounce.ts
│   ├── pages/             # Sayfa bileşenleri
│   │   ├── Landing.tsx
│   │   ├── Login.tsx
│   │   ├── Register.tsx
│   │   ├── Chat.tsx
│   │   ├── Profile.tsx
│   │   ├── Settings.tsx
│   │   └── Bots.tsx
│   ├── services/          # İş mantığı servisleri
│   │   ├── auth.ts
│   │   ├── encryption.ts
│   │   ├── meshNetwork.ts
│   │   ├── messaging.ts
│   │   ├── bot.ts
│   │   └── wall.ts
│   ├── types/             # TypeScript tipleri
│   │   └── index.ts
│   ├── utils/             # Yardımcı fonksiyonlar
│   │   └── date.ts
│   ├── App.tsx
│   ├── App.css
│   └── main.tsx
├── index.html
├── package.json
├── tsconfig.json
├── vite.config.ts
├── tailwind.config.js
└── README.md
```

## 🛠️ Kurulum

### Detaylı Kurulum Adımları

#### 1. Node.js Yükleme

**Windows:**
```powershell
# Node.js indir: https://nodejs.org/
# LTS sürümünü indirin ve kurun
```

**Mac:**
```bash
# Homebrew ile
brew install node

# Veya indir: https://nodejs.org/
```

**Linux (Ubuntu/Debian):**
```bash
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs
```

#### 2. Proje Kurulumu

```bash
# Proje klasörüne gidin
cd meshchat

# Bağımlılıkları yükleyin
npm install

# .env dosyasını oluşturun
cp .env.example .env

# .env dosyasını düzenleyin
nano .env
```

#### 3. Ortam Değişkenleri (.env)

```env
# API URL
VITE_API_URL=http://localhost:3000/api

# WebSocket URL
VITE_WS_URL=ws://localhost:3000/ws

# Uygulama Ayarları
VITE_APP_NAME=MeshChat
VITE_APP_VERSION=1.0.0

# Şifreleme Ayarları
VITE_ENCRYPTION_ENABLED=true
VITE_ENCRYPTION_KEY_SIZE=4096

# Özellik Bayrakları
VITE_ENABLE_MESH_NETWORK=true
VITE_ENABLE_BLUETOOTH=true
VITE_ENABLE_BOT_SYSTEM=true
```

## 💻 Geliştirme

### Geliştirme Komutları

```bash
# Geliştirme sunucusu
npm run dev

# TypeScript kontrolü
npm run type-check

# Lint kontrolü
npm run lint

# Test çalıştırma
npm run test

# Build alma
npm run build

# Preview (build sonrası)
npm run preview
```

### Kod Yazma Kuralları

#### Bileşen Yapısı
```typescript
import React from 'react';
import { Button } from '@/components/ui/button';

interface MyComponentProps {
  title: string;
  onAction: () => void;
}

export const MyComponent: React.FC<MyComponentProps> = ({ title, onAction }) => {
  return (
    <div className="p-4">
      <h2>{title}</h2>
      <Button onClick={onAction}>Tamam</Button>
    </div>
  );
};
```

#### Servis Yapısı
```typescript
export class MyService {
  private static instance: MyService;
  
  private constructor() {}
  
  static getInstance(): MyService {
    if (!MyService.instance) {
      MyService.instance = new MyService();
    }
    return MyService.instance;
  }
  
  async doSomething(): Promise<void> {
    // İş mantığı
  }
}

export const myService = MyService.getInstance();
```

## 📦 Build ve Dağıtım

### Production Build

```bash
# Build al
npm run build

# Build çıktısı dist/ klasöründedir
ls -la dist/
```

### Dağıtım Seçenekleri

#### 1. Netlify

```bash
# Netlify CLI yükle
npm install -g netlify-cli

# Deploy et
netlify deploy --prod --dir=dist
```

#### 2. Vercel

```bash
# Vercel CLI yükle
npm install -g vercel

# Deploy et
vercel --prod
```

#### 3. GitHub Pages

```bash
# gh-pages yükle
npm install -g gh-pages

# Deploy et
gh-pages -d dist
```

#### 4. Kendi Sunucunuz

```bash
# Build dosyalarını sunucuya kopyala
scp -r dist/* user@server:/var/www/meshchat/

# Nginx konfigürasyonu
cat > /etc/nginx/sites-available/meshchat << 'EOF'
server {
    listen 80;
    server_name meshchat.example.com;
    root /var/www/meshchat;
    index index.html;
    
    location / {
        try_files $uri $uri/ /index.html;
    }
    
    location /api {
        proxy_pass http://localhost:3000;
    }
}
EOF
```

## 📱 Google Play Yayınlama

### Adım 1: Android Projesi Oluşturma

MeshChat bir PWA'dır. Android uygulaması olarak yayınlamak için **Trusted Web Activity (TWA)** kullanacağız.

#### 1.1 Bubblewrap Yükleme

```bash
# Node.js 14+ gereklidir
npm install -g @bubblewrap/cli
```

#### 1.2 Proje Başlatma

```bash
# Yeni bir klasör oluştur
mkdir meshchat-android
cd meshchat-android

# Bubblewrap projesi başlat
bubblewrap init --manifest https://siteniz.com/manifest.json
```

#### 1.3 Konfigürasyon

```bash
# Uygulama bilgilerini girin
? Application name: MeshChat
? Short name: MeshChat
? Package name: com.sirketiniz.meshchat
? Launcher name: MeshChat
? Theme color: #3b82f6
? Background color: #ffffff
? Start URL: /
? Icon URL: https://siteniz.com/icons/icon-512x512.png
? Maskable icon URL: https://siteniz.com/icons/maskable-icon-512x512.png
? Display mode: standalone
? Orientation: default
? Include source code for the Chrome extension? No
? Request the following permissions: 
  ◉ internet
  ◉ bluetooth
  ◉ location
```

#### 1.4 Build Alma

```bash
# Android App Bundle (AAB) oluştur
bubblewrap build

# Çıktı: app-release-signed.aab
```

### Adım 2: Google Play Console

#### 2.1 Hesap Oluşturma

1. [Google Play Console](https://play.google.com/console)'a gidin
2. Geliştirici hesabı oluşturun ($25 ücret)
3. Gerekli bilgileri doldurun

#### 2.2 Uygulama Oluşturma

1. "Uygulama oluştur" düğmesine tıklayın
2. Uygulama adı: "MeshChat"
3. Varsayılan dil: Türkçe
4. Uygulama türü: Uygulama
5. Ücretli mi: Ücretsiz

#### 2.3 Store Girişi

**Gerekli görseller:**
- Uygulama ikonu (512x512 PNG)
- Özellik grafiği (1024x500 PNG)
- Ekran görüntüleri (en az 2)
  - Telefon: 1080x1920
  - Tablet: 2048x2732

**Açıklama:**
```
Başlık: MeshChat - Deprem Anında İletişim

Kısa açıklama: 
İnternet olmadan bile çalışan güvenli mesajlaşma uygulaması

Tam açıklama:
MeshChat, deprem ve afet anlarında bile çalışan, telefondan telefona iletişim kuran süper güvenli mesajlaşma uygulamasıdır.

🌐 ÇOKLU BAĞLANTI
• Mobil veri, WiFi, Bluetooth ve Mesh Ağı desteği
• İnternet olmadan bile mesajlaşma
• Otomatik bağlantı geçişi

🔐 GÜVENLİK
• Uçtan uca şifreleme
• Açık kaynak kodlu
• Dijital imza doğrulama

🤖 BOT SİSTEMİ
• Python ve JavaScript bot desteği
• Telegram BotFather tarzı yönetim

📱 SOSYAL ÖZELLİKLER
• Profil duvarı
• Fotoğraf ve video paylaşımı
• Etiketleme ve yorumlar

Açık kaynak projemize katkıda bulunun!
```

#### 2.4 İçerik Derecelendirmesi

1. "İçerik derecelendirmesi" bölümüne gidin
2. Tüm soruları doldurun
3. IARC sertifikası alın

#### 2.5 Uygulama Bülteni

```bash
# AAB dosyasını yükleyin
# - app-release-signed.aab

# İmza sertifikası bilgilerini kaydedin!
```

#### 2.6 Test ve Yayınlama

1. **Dahili test:** Ekibinizle test edin
2. **Kapalı test:** 100 test kullanıcısı
3. **Açık test:** Beta sürüm
4. **Üretim:** Herkese açık yayın

### Adım 3: Otomatik Güncelleme

```bash
# Yeni sürüm çıktığında
bubblewrap update
bubblewrap build

# Yeni AAB'yi Play Console'a yükleyin
```

## 🔌 API Dokümantasyonu

### Kimlik Doğrulama

#### Giriş
```http
POST /api/auth/login
Content-Type: application/json

{
  "email": "kullanici@ornek.com",
  "password": "sifre123"
}
```

**Yanıt:**
```json
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIs...",
  "refreshToken": "eyJhbGciOiJIUzI1NiIs...",
  "user": {
    "id": "user_123",
    "email": "kullanici@ornek.com",
    "username": "kullanici",
    "displayName": "Kullanıcı Adı"
  }
}
```

#### Kayıt
```http
POST /api/auth/register
Content-Type: application/json

{
  "email": "kullanici@ornek.com",
  "password": "sifre123",
  "username": "kullanici",
  "displayName": "Kullanıcı Adı",
  "publicKey": "-----BEGIN PUBLIC KEY-----..."
}
```

### Mesajlaşma

#### Mesaj Gönder
```http
POST /api/messages
Authorization: Bearer <token>
Content-Type: application/json

{
  "receiverId": "user_456",
  "content": "Merhaba!",
  "type": "text",
  "encryptedContent": "...",
  "signature": "..."
}
```

#### Mesajları Getir
```http
GET /api/chats/{chatId}/messages?limit=50&offset=0
Authorization: Bearer <token>
```

### Bot API

#### Bot Oluştur
```http
POST /api/bots
Authorization: Bearer <token>
Content-Type: application/json

{
  "name": "Hava Durumu Botu",
  "username": "havadurumu_bot",
  "description": "Hava durumu bilgisi verir",
  "language": "python"
}
```

#### Bot Mesaj Gönder
```http
POST /api/bots/send
Authorization: Bearer <bot_token>
Content-Type: application/json

{
  "chat_id": "user_123",
  "text": "Merhaba!"
}
```

## 🤖 Bot Geliştirme

### Python Bot Örneği

```python
# bot.py
import requests
import json

class MeshChatBot:
    def __init__(self, token):
        self.token = token
        self.base_url = "https://api.meshchat.com/v1"
    
    def handle_message(self, message):
        text = message.get('content', '')
        chat_id = message.get('senderId')
        
        if text == '/start':
            self.send_message(chat_id, "Merhaba! Bot'a hoş geldiniz.")
        elif text == '/help':
            self.send_message(chat_id, "Yardım menüsü...")
        elif text.startswith('/echo '):
            echo_text = text[6:]
            self.send_message(chat_id, f"Echo: {echo_text}")
    
    def send_message(self, chat_id, text):
        url = f"{self.base_url}/bots/send"
        headers = {"Authorization": f"Bearer {self.token}"}
        data = {"chat_id": chat_id, "text": text}
        response = requests.post(url, headers=headers, json=data)
        return response.json()

# Bot'u çalıştır
if __name__ == "__main__":
    bot = MeshChatBot("YOUR_BOT_TOKEN")
    # Webhook veya polling ile mesajları dinle
```

### JavaScript Bot Örneği

```javascript
// bot.js
class MeshChatBot {
  constructor(token) {
    this.token = token;
    this.baseUrl = 'https://api.meshchat.com/v1';
  }

  async handleMessage(message) {
    const text = message.content || '';
    const chatId = message.senderId;

    if (text === '/start') {
      await this.sendMessage(chatId, 'Merhaba! Bot\'a hoş geldiniz.');
    } else if (text === '/help') {
      await this.sendMessage(chatId, 'Yardım menüsü...');
    } else if (text.startsWith('/echo ')) {
      const echoText = text.slice(6);
      await this.sendMessage(chatId, `Echo: ${echoText}`);
    }
  }

  async sendMessage(chatId, text) {
    const response = await fetch(`${this.baseUrl}/bots/send`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ chat_id: chatId, text }),
    });
    return await response.json();
  }
}

const bot = new MeshChatBot('YOUR_BOT_TOKEN');
```

## 📱 Mobil Uygulama Yapma (Telefondan)

### Seçenek 1: PWA Olarak Yükleme (En Kolay)

**Android:**
1. Chrome'da `https://meshchat.com` açın
2. Menü → "Ana ekrana ekle" seçin
3. Uygulama simgesi ana ekrana eklenir

**iOS:**
1. Safari'de `https://meshchat.com` açın
2. Paylaş düğmesine tıklayın
3. "Ana Ekrana Ekle" seçin

### Seçenek 2: Termux ile Geliştirme (Android)

```bash
# Termux uygulamasını yükleyin (F-Droid'den)

# Güncelleme
pkg update && pkg upgrade

# Node.js yükleme
pkg install nodejs git

# Projeyi klonla
git clone https://github.com/kullaniciadi/meshchat.git
cd meshchat

# Bağımlılıkları yükle
npm install

# Geliştirme sunucusu
npm run dev -- --host

# Telefonunuzun IP adresini öğrenin
ifconfig

# Aynı ağdaki başka bir cihazdan erişin
# http://TELEFON_IP:5173
```

### Seçenek 3: Kod Düzenleyici Uygulamaları

**Önerilen uygulamalar:**
- **Acode** - Android için kod editörü
- **Spck Editor** - Git destekli editör
- **Dcoder** - Mobil IDE

**Acode ile çalışma:**
1. Acode'u yükleyin
2. GitHub'dan projeyi klonlayın
3. Dosyaları düzenleyin
4. Termux ile test edin

### Seçenek 4: GitHub Codespaces (Bulut)

1. GitHub mobil uygulamasını açın
2. Projenize gidin
3. "." tuşuna basın (Codespaces açılır)
4. Tarayıcıda VS Code çalışır
5. Terminal'den `npm run dev` çalıştırın

## ❓ Sık Sorulan Sorular

### Genel Sorular

**S: MeshChat ücretsiz mi?**
C: Evet, tamamen ücretsiz ve açık kaynak.

**S: İnternet olmadan nasıl çalışıyor?**
C: WiFi Direct, Bluetooth ve Mesh ağı teknolojileri kullanıyoruz.

**S: Mesajlarım güvende mi?**
C: Evet, uçtan uca şifreleme kullanıyoruz. Sadece siz ve alıcı okuyabilir.

### Teknik Sorular

**S: Kendi sunucumu kurabilir miyim?**
C: Evet, backend kodları da açık kaynak. Kendi sunucunuzu kurabilirsiniz.

**S: Bot nasıl oluştururum?**
C: Uygulama içinden "Bot Yöneticisi"ne gidin veya API'yi kullanın.

**S: Mesh ağı ne kadar mesafeye kadar çalışır?**
C: Bluetooth ~10m, WiFi Direct ~100m. Her telefon bir tekrarlayıcı görevi görür.

### Mobil Geliştirme

**S: iOS uygulaması var mı?**
C: Şu an sadece PWA olarak kullanılabilir. App Store sürümü yakında.

**S: Telefondan kod yazabilir miyim?**
C: Evet, Termux veya kod editörü uygulamaları kullanabilirsiniz.

**S: Google Play'e nasıl yüklerim?**
C: Yukarıdaki "Google Play Yayınlama" bölümüne bakın.

## 🤝 Katkıda Bulunma

1. Projeyi fork edin
2. Feature branch oluşturun (`git checkout -b feature/amazing`)
3. Değişikliklerinizi commit edin (`git commit -m 'Add amazing feature'`)
4. Branch'inizi push edin (`git push origin feature/amazing`)
5. Pull Request açın

## 📄 Lisans

Bu proje MIT lisansı altında lisanslanmıştır. Detaylar için [LICENSE](LICENSE) dosyasına bakın.

## 🙏 Teşekkürler

- [React](https://reactjs.org/)
- [Vite](https://vitejs.dev/)
- [Tailwind CSS](https://tailwindcss.com/)
- [shadcn/ui](https://ui.shadcn.com/)
- [WebRTC](https://webrtc.org/)
- [Web Bluetooth API](https://web.dev/bluetooth/)

## 📞 İletişim

- **Discord:** [discord.gg/meshchat](https://discord.gg/meshchat)
- **Twitter:** [@meshchat](https://twitter.com/meshchat)
- **Email:** info@meshchat.com
- **Website:** [meshchat.com](https://meshchat.com)

---

**Made with ❤️ for a connected world, even in disasters.**
